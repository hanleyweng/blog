import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.*; 
import java.awt.image.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class DP_v2_classPtest8 extends PApplet {



class bullet {
  float x, y, speed;
  int Quad, ov, oh;
  boolean bulletKill=false;
  boolean changeTargeter=false;
  float tx=0;
  float ty=0;
  float tr=0.5f;
  bullet(float _x, float _y, float _speed, int _quad, int _ov, int _oh) {
    x = _x;
    y = _y;
    speed = _speed;
    Quad = _quad; 
    ov = _ov;
    oh = _oh;
  }
  public void run() {
    stroke(0);
    strokeWeight(3);
    if (bulletKill==false) {
      if (mapArray[round(x+speed*Quad*oh)][round(y+speed*Quad*ov)][0]=='g') {
        x+=speed*Quad*oh;
        y+=speed*Quad*ov;
        point((x+0.5f)*tileWidth,(y+0.5f)*tileHeight);
      } 
      else {
        bulletKill=true;
      }
    }
    if (Quad==0) {
      bulletKill=true;
    }
  }
  public void target(float _targetedx, float _targetedy, int id) {
    tx = _targetedx;
    ty = _targetedy;
    if (dist(x,y,tx,ty)<tr) {
      newBaddies(id);
      bulletKill=true;
    }
  }
  public boolean getkilled() {
    return bulletKill;
  }
  public void exploded() {
    //println("EXPLODED");
  }
}
class pmov {
  float p1gx;
  float p1newgx;
  float p1curgx;
  float p1gy;
  float p1newgy;
  float p1curgy;
  float p1realgx;
  float p1realgy;

  boolean change1001Target=true;


  float p1moveSpeed;//=0.2; //p1moveSpeed<=1 // must be divisible by 1 eg. 1/5=0.2
  int p1moveTime;//=round(1/p1moveSpeed);
  float p1moveTimeDir=1;
  boolean p1move=true;
  int p1curhv01;
  float p1curqdhv;

  int[] p1qd={
    0,0                        };
  int p1hv=1; // player 1 horizontal or veritcal
  float id;

  int p1ov;
  int p1oh;
  pmov(float identification, float p1ux, float p1uy, float p1uSpeed, int p1qdux, int p1qduy) {
    p1gx = p1ux;
    p1newgx = p1ux;
    p1curgx = p1ux;
    p1gy = p1uy;
    p1newgy = p1uy;
    p1curgy = p1uy;
    p1moveSpeed=p1uSpeed;
    p1moveTime=round(1/p1moveSpeed);
    id = identification;
    p1qd[0]=p1qdux;
    p1qd[1]=p1qduy;


    if (random(1)<=0.5f) {
      change1001Target=true;
    } 
    else {
      change1001Target=false;
    }

  }
  public void quads(int x, int y) {
    p1qd[0]=x;
    p1qd[1]=y;
  }
  public void show() {
    //determines player 1's main array-based location
    if (p1move==false) {
      for (int p1detStage=0; p1detStage<=1; p1detStage++) { //p1 determinant stage, 0, 1
        p1hv=-p1hv; //reverses p1hv direction to initially test it, reverts back if determined posn is occupied
        p1ov=(-(p1hv-1)/2); //vertical active, 0 or 1
        p1oh=((p1hv+1)/2); //horizontal active, 0 or 1
        if ((mapArray[round(p1gx+p1qd[0]*p1ov)][round(p1gy+p1qd[1]*p1oh)][0]=='g')&&(abs(p1qd[(p1hv+1)/2])==1)) {
          if (p1detStage==0) {
            //p1qd[(-p1hv+1)/2]=0; // NEEDS EXTERNAL CONTACT
            //temporary player1 only fix.
            if (id==1) {
              p1rootQd[(-p1hv+1)/2]=0;
            }
            if (id==2) {
              p2rootQd[(-p1hv+1)/2]=0;
            }
            // end temporary player1 fix.
            p1hv=-p1hv;
          }
          if (p1detStage==1) {
            p1move=true;
            p1curgx=p1gx;
            p1curhv01=(p1hv+1)/2;
            p1curqdhv=p1qd[p1curhv01];
            p1newgx=p1gx+(p1qd[0])*p1ov;
            p1curgy=p1gy;
            p1newgy=p1gy+(p1qd[1])*p1oh;
          }
        } 
        else {
          if (p1detStage==1) {
            //when p1 has stopped moving, queued directions are reset
            //p1qd[0]=0;
            //p1qd[1]=0; // NEEDS EXTERNAL CONTACT
            //temporary player1 only fix
            if (id==1) {
              p1rootQd[0]=0;
              p1rootQd[1]=0;
            }
            if (id==2) {
              p2rootQd[0]=0;
              p2rootQd[1]=0;
            }
            if (id==1000) {
              float tdeltay=player1.gety()-p1realgy;
              int tyqd = round(tdeltay/abs(tdeltay));
              float tdeltax=player1.getx()-p1realgx;
              int txqd = round(tdeltax/abs(tdeltax));
              p1qd[0]=txqd;
              p1qd[1]=tyqd;
            }
            if (id==1000.5f) {
              float tdeltay=player2.gety()-p1realgy;
              int tyqd = round(tdeltay/abs(tdeltay));
              float tdeltax=player2.getx()-p1realgx;
              int txqd = round(tdeltax/abs(tdeltax));
              p1qd[0]=txqd;
              p1qd[1]=tyqd;
            }
            if (id==1001) {
              float tdeltay,tdeltax;
              if (random(1)<0.3f) {
                change1001Target=!change1001Target;
              }
              if (players==2) {
                change1001Target=true;
              }
              if (change1001Target==true) {
                tdeltay=player1.gety()-p1realgy;
                tdeltax=player1.getx()-p1realgx;
              } 
              else {
                tdeltay=player1.gety()-p1realgy;
                tdeltax=player1.getx()-p1realgx;
                if (players==2) {
                  tdeltay=player2.gety()-p1realgy;
                  tdeltax=player2.getx()-p1realgx;
                }
              }
              int tyqd = round(tdeltay/abs(tdeltay));
              int txqd = round(tdeltax/abs(tdeltax));
              p1qd[0]=txqd;
              p1qd[1]=tyqd;
            }
            if (id==1002) {
              float tdeltay,tdeltax;
              if (round(random(1))==0) {
                tdeltay=player1.gety()-p1realgy;
                tdeltax=player1.getx()-p1realgx;
              } 
              else {
                tdeltay=player1.gety()-p1realgy;
                tdeltax=player1.getx()-p1realgx;
                if (players==2) {
                  tdeltay=player2.gety()-p1realgy;
                  tdeltax=player2.getx()-p1realgx;
                }
              }
              int tyqd = round(tdeltay/abs(tdeltay));
              int txqd = round(tdeltax/abs(tdeltax));
              p1qd[0]=txqd;
              p1qd[1]=tyqd;
            }
            //end temporary player1 fix
          }
        }
      }
    }
    //between-grid-movement: calculating player1's location
    if (p1move==true) {
      if (p1moveTime<=1/p1moveSpeed) {
        p1realgx=(p1newgx-p1curgx)*p1moveSpeed*p1moveTime+p1curgx; //multiply absolute to render intial 0 mute
        p1realgy=(p1newgy-p1curgy)*p1moveSpeed*p1moveTime+p1curgy;
        if ((p1moveTimeDir==1)||(p1moveTimeDir==0)) {
          if (p1moveTime==1/p1moveSpeed) {
            p1moveTime=0;
            p1move=false;
            p1gx=p1newgx;
            p1curgx=p1gx;
            p1gy=p1newgy;
            p1curgy=p1gy;
          }
        }
        p1moveTimeDir=p1curqdhv*p1qd[p1curhv01];
        p1moveTime+=p1moveTimeDir;
        if (p1moveTime==-1) {
          p1moveTime=1;
          p1move=false;
        }
      }
    }
    //drawing player1 + returning values
    strokeWeight(10);
    if (id==1) {
      stroke(255,100,100);
    }
    if (id==2) {
      stroke(0,100,200);
    }
    if (id==1000) {
      stroke(0,200,200);
    }
    if (id==1000.5f) {
      stroke(0,200,200);
    }
    if (id==1001) {
      stroke(0,200,0);
    }
    if (id==1002) {
      stroke(0,0,200);
    }
    //point(p1realgx*tileWidth+tileWidth/2,p1realgy*tileHeight+tileHeight/2);
    float displayx=p1realgx*tileWidth+tileWidth/2;
    float displayy=p1realgy*tileHeight+tileHeight/2;
    point(displayx,displayy);
    //drawChar(displayx,displayy,5,5,2);
  }
  public float getx() {
    return p1realgx;
  }
  public float gety() {
    return p1realgy;
  }
  public float gethv() {
    return p1hv;
  }
  public float getid() {
    return id;
  }
  public int getqd() {
    return p1qd[(p1hv+1)/2];
  }
  public int getov() {
    return p1oh;
    //reversed because it was used to read a reversed p1hv
  }
  public int getoh() {
    return p1ov;
  }
}















public void startBullet(int pId) {
  if (pId==1) {
    bullets[orbsp1usedorbs] = new bullet(player1.getx(),player1.gety(),bulletSpeed,player1.getqd(), player1.getov(),player1.getoh());
    orbsp1usedorbs++;
    p1engageBullet=false;
  }
  if (pId==2) {
    bullets[orbsp2usedorbs] = new bullet(player2.getx(),player2.gety(),bulletSpeed,player2.getqd(), player2.getov(),player2.getoh());
    orbsp2usedorbs++;
    p2engageBullet=false;
  }
}
public void starting() {
  image(title,0,0,width,height);
  if (mousePressed) {
    if (mouseX<width/2) {
      println("l");
      players=1;
    } 
    else {
      println("r");
      players=2;
    }
    startScreen=false;
  }
}

public void draw() {
  if (startScreen==true) {
    starting();
  }
  if (startScreen==false) {
    if (p1engageBullet==true) {
      startBullet(1);
    }
    if (p2engageBullet==true) {
      startBullet(2);
    }
    drawMap();
    keyDoor();
    for (int i=0; i<orbLoadNum; i++) {
      orbs[i].showing();
      if (orbs[i].getDisplay()==true) {
        orbs[i].hitTest(player1.getx(),player1.gety(), 1);
        if (players==2) {
          orbs[i].hitTest(player2.getx(),player2.gety(), 2);
        }
        orbs[i].run();
      }
    }

    player1.quads(p1rootQd[0],p1rootQd[1]);
    player1.show();
    if (players==2) {
      player2.quads(p2rootQd[0],p2rootQd[1]);
      player2.show();
    }

    //baddies
    for (int i=0; i<baddies.length; i++) {
      baddies[i].show();
      noStroke();
      fill(255,0,0,20);
      if(dist(baddies[i].getx(),baddies[i].gety(),player1.getx(),player1.gety())<0.5f) {
        rect(0,0,width,height);
        p1score-=1;
      }
      if (players==2) {
        if(dist(baddies[i].getx(),baddies[i].gety(),player2.getx(),player2.gety())<0.5f) {
          rect(0,0,width,height);
          p2score-=1;
        }
      }
    }
    //p1
    for (int h=orbsp1deadorbs; h<orbsp1usedorbs; h++) {
      if (bullets[h].getkilled()==false) {
        for (int i=0; i<baddies.length; i++) {
          bullets[h].target(baddies[i].getx(),baddies[i].gety(), i);
        }
        bullets[h].run();
      } 
      else {
        orbsp1deadorbs++;
        bullets[h].exploded();
      }
    }
    //p2
    for (int h=orbsp2deadorbs; h<orbsp2usedorbs; h++) {
      if (bullets[h].getkilled()==false) {
        for (int i=0; i<baddies.length; i++) {
          bullets[h].target(baddies[i].getx(),baddies[i].gety(), i);
        }
        bullets[h].run();
      } 
      else {
        orbsp2deadorbs++;
        bullets[h].exploded();
      }
    }

    drawiBad(iBadx,iBady);

    String string1="P1shots: "+(orbsp1emptyslot-orbsp1usedorbs)+" ";
    displayText(string1,0,0,1000,100,font1,255,255,255,0.5f);
    String string3="P1score: "+p1score+" ";
    displayText(string3,0,253,1000,100,font1,255,255,255,0.5f);
    if (players==2) {
      String string2="P2shots: "+(orbsp2emptyslot-orbsp2usedorbs)+" ";
      displayText(string2,150,0,1000,100,font1,255,255,255,0.5f);
      String string4="P2score: "+p2score+" ";
      displayText(string4,150,253,1000,100,font1,255,255,255,0.5f);
    }


    if (WON==true) {
      noStroke();
      fill(0);
      rect(0,0,width,height);

      String stringEnd = "You've Escaped! Thanks For Playing";
      displayText(stringEnd,15,130,1000,100,font1,255,255,255,0.4f);
      string3="P1score: "+finalp1score+" ";
      displayText(string3,0,253,1000,100,font1,255,255,255,0.5f);
      if (players==2) {
        String string4="P2score: "+finalp2score+" ";
        displayText(string4,150,253,1000,100,font1,255,255,255,0.5f);
      }
    }
  }
}

public void displayText(String _text, float _x, float _y, float _width, float _height, PFont _font, float r, float g, float b,float _scale) {
  pushMatrix();
  translate(_x,_y);
  scale(_scale);
  textFont(_font);
  fill(r,g,b);
  text(_text,_x,_y,_width,_height);
  popMatrix();
}











public void drawChar(float charx, float chary, float charr, float charrb, float sw) {
  pushMatrix();
  translate(charx,chary);
  fill(100,200,255);
  ellipse(0,0,charr,charr);
  strokeWeight(sw);
  //line(charr,0,charr+charr,-charr);
  noFill();
  bezier(charr,0, charr+charrb,0, charr+charr,-charr+charrb, charr+charr,-charr);
  //line(-charr,0,-charr-charr,-charr);
  bezier(-charr,0, -charr-charrb,0, -charr-charr,-charr+charrb, -charr-charr,-charr);
  popMatrix();
}

public void drawMap() {
  noStroke();
  for (int curxTile=0; curxTile<columns; curxTile++) {
    for (int curyTile=0; curyTile<rows; curyTile++) {
      if (mapArray[curxTile][curyTile][0]=='w') {
        fill(100,50,50);
      }
      if (mapArray[curxTile][curyTile][0]=='g') {
        fill(200,200,250);
        //fill(255);
      }
      rect(curxTile*tileWidth,curyTile*tileHeight,tileWidth,tileHeight);
      fill(0,0,255);
      //rect((curxTile+0.5)*tileWidth,(curyTile+0.5)*tileHeight,1,1);
    }
  }
}

public void drawKey(float x, float y) {
  stroke(255,255,0);
  strokeWeight(10);
  point((x+0.5f)*tileWidth,(y+0.5f)*tileHeight);
}
public void drawDoor(float x, float y) {
  stroke(255,100,0);
  strokeWeight(15);
  point((x+0.5f)*tileWidth,(y+0.5f)*tileHeight);
}
public void drawDoorO(float x, float y) {
  stroke(255,255,0);
  strokeWeight(15);
  point((x+0.5f)*tileWidth,(y+0.5f)*tileHeight);
}
public void drawiBad(float x, float y) {
  stroke(100,255,0);
  strokeWeight(15);
  point((x+0.5f)*tileWidth,(y+0.5f)*tileHeight);
}

public void keyDoor() {
  drawDoor(doorx,doory);
  if (keyHolder==0) {
    drawKey(keyx, keyy);
    if (dist(keyx,keyy,player1.getx(),player1.gety())<0.5f) {
      keyHolder=1;
    }
    if (players==2) {
      if (dist(keyx,keyy,player2.getx(),player2.gety())<0.5f) {
        keyHolder=2;
      }
    }
  } 
  else {
    if (keyHolder==1) {
      if (dist(doorx,doory,player1.getx(),player1.gety())<0.5f) {
        //keyHolder=1;
        keyHolder=3;
      }
    }
    if (players==2) {
      if (keyHolder==2) {
        if (dist(doorx,doory,player2.getx(),player2.gety())<0.5f) {
          keyHolder=4;
        }
      }
    }
    //
    if (keyHolder==3) {
      if (players==2) {
        if (dist(doorx,doory,player2.getx(),player2.gety())<0.5f) {
          //stop running p1
          keyHolder=100;
        }
      } 
      else {
        keyHolder=100;
      }
    }
    if (keyHolder==4) {
      if (dist(doorx,doory,player1.getx(),player1.gety())<0.5f) {
        //stop running p2
        keyHolder=100;
      }
    }
    if ((keyHolder==3)||(keyHolder==4)) {
      drawDoorO(doorx,doory);
    }
    if (keyHolder==100) {
      //mapArray=mapArray5;
      level++;
      println(level);
      if (level>=5) {
        println("YOU WON");
        finalp1score = p1score;
        finalp2score = p2score;
        WON = true;
        level=0;
      } 
      else {
        mapArray=mapArrayWhole[level];
        reInitialize();
        println("Door Entered");
        keyHolder=0;
      }
    }
  }
}

public void keyPressed() {
  if (!(keyHolder==3)) {
    if (key==CODED) {
      if (keyCode==LEFT) {
        p1rootQd[0]=-1;
        //p1x=-1;
      }
      if (keyCode==RIGHT) {
        p1rootQd[0]=1;
        //p1x=1;
      }
      if (keyCode==DOWN) {
        p1rootQd[1]=1;
        //p1y=1;
      }
      if (keyCode==UP) {
        p1rootQd[1]=-1;
        //p1y=-1;
      }
    }
    if (key==ENTER) {
      if ((orbsp1emptyslot-orbsp1usedorbs)>0) {
        if (p1engageBullet==false) {
          p1engageBullet=true;
        }
      }
    }
  }
  if (!(keyHolder==4)) {
    if (key=='e') {
      if ((orbsp2emptyslot-orbsp2usedorbs)>0) {
        if (p2engageBullet==false) {
          p2engageBullet=true;
        }
      }
    }
    if (key=='a') {
      p2rootQd[0]=-1;
    }
    if (key=='d') {
      p2rootQd[0]=1;
    }
    if (key=='w') {
      p2rootQd[1]=-1;
    }
    if (key=='s') {
      p2rootQd[1]=1;
    }
    if (key=='o') {
      fps+=fpsM;
      println(fps);
    }
    if (key=='l') {
      if (fps>fpsM) {
        fps-=fpsM;
        println(fps);
      } 
      else {
        fps=1;
      }
    }
  }
}








////////////////////////////////////////////////////////////////////////////////////////
//number of boxes = number of childs in array
//w=wall <- unpassable
//g=ground <- walkable
//o=default
//a=player1start
//b=player2start
//c=player3start
//d=player4start

int[][] enemyTypes = {{2,1,0},{4,1,0},{4,1,0},{6,3,1},{8,2,2}};

char[][][][] mapArrayWhole = 

{
  
{{{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'g','r'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'g','o'},{'g','r'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'}}, 
 {{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'w','o'},{'g','a'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','k'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'g','t'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'g','d'},{'g','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'w','o'},{'g','b'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'g','o'},{'g','r'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'g','r'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}},
 
 
 
 {{{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','a'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','d'},{'w','o'},{'g','k'},{'g','o'},{'g','o'},{'g','t'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','b'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}},
 
{{{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','a'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'w','o'},{'w','o'},{'g','t'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','k'},{'w','o'},{'g','d'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'}}, 
 {{'w','o'},{'g','b'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'}}, 
 {{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}},
 
 
 
 {{{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','a'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'g','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','k'},{'w','o'},{'w','o'},{'w','o'},{'g','t'},{'w','o'},{'w','o'},{'g','d'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','b'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'}}, 
 {{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}},
 
 
{{{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','a'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'g','k'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','t'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','d'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','b'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'}}, 
 {{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'}}, 
 {{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}},
 
 
 
 
 
  

//char[][][] mapArray0 = 
//
//{{{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','a'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','b'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'g','o'},{'g','t'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}},
// {{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}},
// 
//// char[][][] mapArray1 = 
//{{{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','d'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'g','a'},{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'g','t'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'g','b'},{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','k'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}}, 
// 
//// char[][][] mapArray2 = 
// {{{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'g','a'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','k'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'g','t'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','d'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','b'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}},
// 
//// char[][][] mapArray3 = 
// {{{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'}}, 
// {{'w','o'},{'g','a'},{'w','o'},{'g','o'},{'w','o'},{'g','k'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','t'},{'w','o'}}, 
// {{'w','o'},{'g','b'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','d'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}},
// 
//// char[][][]mapArray4 = 
// {{{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','d'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','a'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','t'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','b'},{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','k'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}},
// 
//// char[][][]mapArray5 = 
// {{{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','k'},{'g','r'},{'g','a'},{'g','b'},{'g','o'},{'g','o'},{'g','r'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','d'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','r'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','r'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','t'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}},
// 
//// char[][][]mapArray6 = 
// 
// {{{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'g','a'},{'g','b'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','k'},{'w','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','t'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','d'},{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}},
// 
// {{{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','a'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','t'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','b'},{'g','r'},{'g','r'},{'g','r'},{'g','k'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','d'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'w','o'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'g','r'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'g','o'},{'w','o'}}, 
// {{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'},{'w','o'}}}, 
// 
// 
 };
 
 
char[][][] mapArray=mapArrayWhole[0];
//0 no key or door
//1 no bullets + empty space
//2 no Bullets
//3 Grided Linear - Enemies on Outside
//4 Enemies get stuck, waiting 
//5 Debug Linear Testing
//6 Debug Rectangle Testing
//7 Debug Bullets Testing











 


class orb {
  float x,y;
  int id;
  boolean dip1=true;
  boolean dip2=true;
  boolean dip=true;
  orb(float _x, float _y, int _id) {
    x = _x;
    y = _y;
    id = _id;
  }
  public void showing() {
    for (int j=0; j<orbsp1emptyslot; j++) {
      if (orbsp1list[j]==id) {
        j=orbsp1emptyslot+1;
        dip1 = false;
      }
      if (j==(orbsp1emptyslot-1)) {
        dip1 = true;
      }
    }
    for (int j=0; j<orbsp2emptyslot; j++) {
      if (orbsp2list[j]==id) {
        j=orbsp2emptyslot+1;
        dip2 = false;
      }
      if (j==(orbsp2emptyslot-1)) {
        dip2 = true;
      }
    }
    if ((dip1==true)&&(dip2==true)) {
      dip=true;
    } else {
      dip=false;
    }
  }
  public boolean getDisplay() {
    return dip;
  }
  public void hitTest(float _x, float _y, float _pId) {
    if (dist(x,y,_x,_y)<0.1f) {
      if (_pId==1) {
        orbsp1list[orbsp1emptyslot]=id;
        orbsp1emptyslot++;
        p1score+=5;
      }
      if (_pId==2) {
        orbsp2list[orbsp2emptyslot]=id;
        orbsp2emptyslot++;
        p2score+=5;
      }
    }
  }
  public void run() {
    strokeWeight(10);
    stroke(200,100,200);
    point((x+0.5f)*tileWidth,(y+0.5f)*tileHeight);
  }
}





PFont font1;

public void setup() {
  title = loadImage("title3.jpg");
  font1 = loadFont("ArialRoundedMTBold-48.vlw");

  //orbsp1list[0]=1;
  frameRate(fps);
  size(round(stageWidth),round(stageHeight));
  noStroke();
  
  reInitialize();
  //readMapGs();
  
}


public void readMapGs() {
    for (int curxTile=0; curxTile<columns; curxTile++) {
    for (int curyTile=0; curyTile<rows; curyTile++) {
      if (mapArray[curxTile][curyTile][0]=='g') {
        if (mapArray[curxTile][curyTile][1]=='a') {
          player1 = new pmov(1, curxTile, curyTile, 0.1f,0,0);
        }
        if (players==2) {
          if (mapArray[curxTile][curyTile][1]=='b') {
            player2 = new pmov(2, curxTile, curyTile, 0.1f,0,0);
          }
        }
        if (mapArray[curxTile][curyTile][1]=='t') {
          iBadx=curxTile;
          iBady=curyTile;
          for (int i=0; i<baddies.length; i++) {
            newBaddies(i);
          }
        }
        if (mapArray[curxTile][curyTile][1]=='k') {
          keyx=curxTile;
          keyy=curyTile;
        }
        if (mapArray[curxTile][curyTile][1]=='d') {
          doorx=curxTile;
          doory=curyTile;
        }
        if (mapArray[curxTile][curyTile][1]=='r') {
          orbs[orbLoadNum] = new orb(curxTile,curyTile,orbLoadNum);
          orbLoadNum++;
        }
      }
    }
  }
}
  

public void newBaddies(int i) {
  if (i<(numDashers+numBots+numTanks)) {
    baddies[i] = new pmov(1002, iBadx, iBady, 0.2f,0,0);
  }
  if (i<(numBots+numTanks)) {
    baddies[i] = new pmov(1001, iBadx, iBady, 0.1f,0,0);
  }
  if (i<numTanks) {
    float j;
    //setting targetting for p2
    if (players==2) {
      j=(i%2)*0.5f;
    } else {
      j=0;
    }
    baddies[i] = new pmov(1000+j, iBadx, iBady, 0.05f,0,0);
  }
}



////////////////////////////////////////////////////////////////////////////////////////
///Array to Map/////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
int players=2;
////////////////////////////////////////////////////////////////////////////////////////
float stageWidth=400;
float stageHeight=400;
float rows=19;
float columns=19;
float stageArea=rows*columns;
float tileHeight=stageHeight/rows;
float tileWidth=stageWidth/columns;
float minimapHeight=sqrt(2);
float minimapWidth=sqrt(2);
//global co-ordinates range from 0 to rows-1, 0 to columns-1
int fps=41;
int fpsM=5;
////////////////////////////////////////////////////////////////////////////////////////
int[] p1rootQd={
  0,0};
int[] p2rootQd={
  0,0};
////////////////////////////////////////////////////////////////////////////////////////
int level=3; // level 1 is actually level 2
////////////////////////////////////////////////////////////////////////////////////////
pmov player1;
pmov player2;

PImage title;
boolean WON=false;
int finalp1score;
int finalp2score;

float bulletSpeed=0.5f;

//Baddies = tanks,bots,dashers
int numTanks=20; // all baddies right now are grouped // prob better named as 'ghosts' //Only have 2 Tanks (they overlap), but if multiple, can do Hevier damage.
int numBots=1; // increasing these will make them split
int numDashers=1; // increasing these will make them split
int numBaddies = numTanks+numBots+numDashers;//goes up from 0 to numBaddies-1
pmov[] baddies = new pmov[numBaddies];
int iBadx;
int iBady;

float keyx, keyy;
float doorx, doory;
int keyHolder=0;

bullet[] bullets = new bullet[PApplet.parseInt(stageArea)];

orb[] orbs = new orb[PApplet.parseInt(stageArea)];
int orbLoadNum=0;
int[] orbsp1list=new int[PApplet.parseInt(stageArea)];
int orbsp1emptyslot=0;
int orbsp1usedorbs=0;
int orbsp1deadorbs=0;
int[] orbsp2list=new int[PApplet.parseInt(stageArea)];
int orbsp2emptyslot=0;
int orbsp2usedorbs=0;
int orbsp2deadorbs=0;

boolean p1engageBullet=false;
boolean p2engageBullet=false;

int p1score=0;
int p2score=0;


boolean startScreen=true;


public void reInitialize() {

  numTanks=enemyTypes[level][0];
  numBots=enemyTypes[level][1];
  numDashers=enemyTypes[level][2];
  numBaddies = numTanks+numBots+numDashers;
  baddies = new pmov[numBaddies];

  p1rootQd[0]=0;
  p1rootQd[1]=0;
  p2rootQd[0]=0;
  p2rootQd[1]=0;

  keyHolder=0;


  //bullet[] bullets = new bullet[int(stageArea)];

  //orb[] orbs = new orb[int(stageArea)];
  for (int i=0; i<orbLoadNum; i++) {
    orbsp1list[i]=0;
  }
  //int[] orbsp1list=new int[int(stageArea)];
  orbsp1emptyslot=0;
  orbsp1usedorbs=0;
  orbsp1deadorbs=0;
  for (int i=0; i<orbLoadNum; i++) {
    orbsp2list[i]=0;
  }
  //int[] orbsp2list=new int[int(stageArea)];
  orbsp2emptyslot=0;
  orbsp2usedorbs=0;
  orbsp2deadorbs=0;

  p1engageBullet=false;
  p2engageBullet=false;

  //  numOrbsLoaded=0;
  orbLoadNum=0;
  readMapGs();
}









  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#ffffff", "DP_v2_classPtest8" });
  }
}
