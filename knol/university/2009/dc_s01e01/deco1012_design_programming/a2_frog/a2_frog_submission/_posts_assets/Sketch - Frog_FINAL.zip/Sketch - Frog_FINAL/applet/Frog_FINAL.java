import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.*; 
import java.awt.image.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Frog_FINAL extends PApplet {

//A_FROG'S_LIFE/////////////////////////////////////////////////////////////
//External Images: Lillys, Lillypads, Sun and Moon drawn in Adobe Flash CS4.
//External Images: Clouds and Stars created in Adobe Photoshop CS4.
//External Images: A Frog's Life Title created in Adobe Photoshop CS4.
//VARIABLES - IMAGES////////////////////////////////////////////////////////
PImage lillypad;
PImage lilly;
PImage sun;
PImage moon;
PImage clouds; //2000x400
PImage stars; //2000x400
PImage titleIMG;
public void setup() {
  size(400,400);
  lillypad=loadImage("DP-pics-lillypad.png");
  sun=loadImage("DP-pics-sun.png");
  moon=loadImage("DP-pics-moon.png");
  lilly=loadImage("DP-pics-lilly.png");
  clouds=loadImage("DP-pics-clouds.png");//use gif on very laggy pc's
  stars=loadImage("DP-pics-stars.png");//use gif on very laggy pc's
  titleIMG = loadImage("AFROGSLIFE.gif");
  smooth();
}
//Title///////////////////////////////////////////////////////////
float title_time; // create readable time variable
float title_inc=3; //increment of strokes (Up for laggy computers)
float titleStrokeWeightIn=3;
float titleStrokeWeightOut=3;
float title_introV=3;//intro speed
float title_introMaxTime=300;//time taken for gradient lines
float title_introLag=1000;//time taken by intro
float title_outTime=5000;//tme to outro comes in
float title_outV=0.3f;//dictates speed of outro
//Clouds/////////////////////////////////////////
float cloudTime;
float cloudV=0.5f;//\u2202 time increments
float cloudMaxAlpha=0.9f;
float cloudAlpha=cloudMaxAlpha;//initial alpha
float cloudMinAlpha=0.15f;//minimum alpha reachable
//Stars/////////////////////////////////////////
float starTime;
float starVz=0.01f;//\u2202 time increments (speed)
float starMinAlpha=0.15f;//as 4 clouds
float starMaxAlpha=1;
float starAlpha=starMinAlpha;//comes after clouds, so initial minimum
float starLoops=0;//time-based value for looping img
//CELESTIAL OBECT PROPERTIES (SUN + MOON)////////
PImage celestialObject;
float celestialRadius;
float celestialAlpha;
float sunPeriod=50000;//sun speed,faster during work=more efficient
float sunTime=0;
float sunSpaceAdd=50;//precautionary lag
float sunPctgMid;//for transitionary equations - distance to middle height
float sunOneMinusPctgMid; //1-sunPctgMid;
float sunPctgMidSqrt; // sqrt of above, more rounded off value
float sunOneMinusPctgMidSqrt; //1-sunPctgMidSqrt;
//Sun/////////////////////////////////////////////
float sunRad=95; //determines sun size
float sunAlpha=0.9f; // sun alpha
//Moon////////////////////////////////////////////
float moonRad=60; //same4sun
float moonAlpha=0.8f;//same4sun
//////////////////////////////////////////////////
float lillySPEED=20; // smaller = faster
float lillyRange=6200; // y-spread
float lillypadGtime=0; // global time
float lillypadGeta; // eta=esitimated time of arrival
float lillyGtime=0; //lillys same4lillyPad
float lillyGeta;//lillys same4lillyPad
float lillyTimePlus=20;//lilly, precautionary additional time
//Lillypad////////////////////////////////////////
float lillypadRad=50; //determines size
float lillypadSpacingAdd=150;//precautionary time+
float lillypadLagMax=lillyRange;//y-spread
int lillypadNoiseS=round(random(2));//setting noise, sometimes random
float lillypadMinRad=50; //minimum size determinant
float lillypadMaxRad=120; //maximum size determinant
int alillypadStart=1; //used during loop for number of lillypads
float alillypadEnd=90; //number of lillypads
float lillypadTime;
//Lilly////////////////////////////////////////
float lillyMinRad=20; //as4lillypad
float lillyMaxRad=70; //as4lillypad
float lillyLagMax=lillyRange; //as4lillypad
int lillyNoiseS=round(random(2));//at times corresponds to lillypad noise (1/3)
int alillyStart=1; //as4lillypad
float alillyEnd=45; //as4lillypad
float lillyTime; //as4lillypad
float lillySpacingAdd=150; //as4lillypad
///////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////
//CELL VARIABLES////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
float cell_R=170; //colors - more easy to edit from here
float cell_G=200;
float cell_B=100;
////////////////////////////////////////////////////////////////////////
float cell_midPointWeight=20; //size of middle point
////////////////////////////////////////////////////////////////////////
float cell_period=4; // Speed of Pulsations
float cell_lengthi=2; //small variable in the 'bounciness' of pulse
float cell_amplitude=50;//ring amplitudes
float cell_initialdelta;
float cell_headMovement=1.3f; // >0 //bobbiness of main central pulse
float cell_maxHeadSize=15; //size of main

float cell_x=0;
float cell_angle=-50; // specific position / twirliness of spiral
float cell_innerScale099=10; //0}10
float cell_alpha=1; // trasparency
////////////////////////////////////////////////////////////////////////
float cell_scaleMin=0; //minimum+maximum spiral scales
float cell_scaleMax=1.2f;//1.5;
float cell_translationMin=200;//minimum+maximum translations scales
float cell_translationMax=-600;
float cell_innerScaleMin=1;//minimum+maximum \u2202 in spiral shapes
float cell_innerScaleMax=10;
//CELL TIMELINE/////////////////////////////////////////////////////////
float cell_translationTime=15000; // time taken for translation morph
float cell_scaleTime=15000; // Extend Past end of Cell Animation
float cell_endTime=cell_translationTime-2000; //sets approximate start 4 frog
float cell_innerScaleTime=6000; //time taken for innerScale morph
float cell_alphaOutroTime=3000; // time taken to fade out
float cell_totalTime=cell_endTime+cell_alphaOutroTime; //total cell time taken
float cell_timelineStart=100;//0;
float cell_translationStartTime=0; //when translation starts
float cell_scaleStartTime=0; // when scaling starts
float cell_innerScaleStartTime=1000; // when spiral \u2202 shapes start
float cell_time=-cell_timelineStart; //give celltime a start up time
float cell_timeInc=20; //increment of time
boolean cell_initiate=false; //starts the cell animation
float cell_firstInitiateLag=5000; //lags cell animation after started

//////////////////////////////////////////////////////////////////////////////
//FROG VARIABLES//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
float frog_time=0;
//Timeline variables - for FROG
//////periodically turns on each evolutionary stage
boolean stage0TaleInc=false; 
boolean stage1BkLegs=false;
boolean stage3eyes=false;//boolean stage2TaleDec=false; // Handled
boolean stage4FtLegs=false;
float timeline_frog;
//////setting amount of time taken for each stage and at what time they come in
float stage0Lag=8000;
float stage0TaleIncTime=5000;
float stage01Lag=stage0Lag+stage0TaleIncTime+5000;
float stage01Time=10000;
float stage1Lag=stage01Lag+stage01Time*1/5;
float stage1Time=6000;
float stage3Lag=stage01Lag+stage01Time*2/5;
float stage3Time=3000;
float stage4Lag=stage01Lag+stage01Time*3/5;
float stage4Time=4000;
float stageNintroLag=22000+4000;
float stageNintroTime=1000;
float stageNoutroLag=stageNintroLag+stageNintroTime+2000;
float stageNoutroTime=2000;
//////total time, with a little time gap
float stageTOTALTIME=stageNoutroLag+stageNoutroTime+1000;
//////////////////////////////////////////////////////////////////////////////
//leg variables
float legIncrementRatio=3; // HIGHER RATIO FOR LAGGY COMPS
float leg_time=0;
float leg_timeAdd=100;
float legSpeed=30; // leg speed
float legLength; // leg 'length' - initial makings of leg
float legRLength; // leg real length - scales leg to right size
float legRlegLength=0.1f;
float legRarmLength=0.05f;
float legLengthMin=0.2f; // minimum length of leg
float legAmp=15; // a variable that controls hight of leg
float legVarAmp=legAmp/legLength*legRLength; //variation in amplitude
float legAlteringDeterminant; //determines if leg is going fast or slow periodically
float leg_sinLAD; //the sin value of the Leg.Altering.Determinant
float leg_sinLADamp=0; // above's amplitude
float leg_LADspeed=1.1f; // above's periodic speed up in a ratio
float leg_translationRad; //the radius of the set leg, set at the body of frog
float leg_translationAngDelta=40; // angle of back legs
float leg_ARMtranslationAngDelta=50; // max angle of front legs
float leg_armAlpha=255; //transparency of arms (for when introduced)
float leg_translationAng; //the change in angle in limbs for swimming
//////////////////////////////////////////////////////////////////////////////
//tale variables -- meant to be TAIL - 
//////initially mispronounced, and just continued using it for consistency
//following variables - act same as the cell 3rd section variables
///////just in a straight line
float tale_period=4;
float tale_lengthi=1;
float tale_widthRat=3;
float tale_amplitude=15;
float tale_initialdelta;
float tale_headMovement=1.5f;
float tale_maxHeadSize=25;
float tale_addHeadSize=tale_maxHeadSize*0.1f;
float tale_xIncrement=0.5f; // HIGHER FOR LAGGY COMPS // will make tail lighter
float tale_time;
float taleX;
//////////////////////////////////////////////////////////////////////////////
//eye variables
float eyeRad=5; // maximum radius of the frog's eyes
//////////////////////////////////////////////////////////////////////////////
//frog Whole Function Group Variables
//////translations of the frog's position
float frog1_translateX;
float frog1_translateY;
float frog2_translateX;
float frog2_translateY;
//////distance between the frogs
float frogs_amplitudeU=100;
float frogs_amplitudeV=10;
float frogs_amplitude=frogs_amplitudeU;
float frogs_twineTime=0;
//////twine = intertwining // variables of Frog's 'mating'
float frogs_twineTimeIncMin=1;
float frogs_twineTimeIncMax=20;
float frogs_twineTimeInc=frogs_twineTimeIncMin;
//////certain colors of Frog, \u2202 for different frog
float frog_eyeR=100;
float frog_eyeG=255;
float frog_eyeB=100;
float frog_bodR=0;
float frog_bodG=255;
float frog_bodB=0;

//float screenz=0;
public void draw() {
  //  screenz++;
  //  if (screenz%150==0) {
  //    saveFrame();
  //  }
  if (millis()<=(title_outTime+2000)) {
    //Running the title through a set amount of time;
    drawTitle();
  } 
  else {
    //BG////////////////////////////////////////////////////////////////////////
    //for simplicity's sake, the sun is mentioned as a celestial obect
    //so the term sun in this case incorporates both the Sun and the Moon
    //SUN - calculating some initial time related variables, utilised in eqns/////
    sunTime=millis();
    float sunPeriodicFloor=floor(sunTime/sunPeriod);
    sunTime=(sunTime-sunPeriodicFloor*sunPeriod);
    sunPctgMid=1-abs(sunTime/(sunPeriod/2)-1);
    sunOneMinusPctgMid=1-sunPctgMid;
    sunPctgMidSqrt=sqrt(sunPctgMid);
    sunOneMinusPctgMidSqrt=1-sunPctgMidSqrt;
    ///////////CELESTIAL OBJECTS///SUN+MOON///////////////////////////////////////
    background(200,200,255);
    if (sunPeriodicFloor%2==0) { // periodically changes between moon and sun
      //sets celestial object's properties to that of the sun
      celestialObject=sun;
      celestialRadius=sunRad;
      celestialAlpha=sunAlpha;
      //NOTE: These two lines to be turned off correspondingly for slightly slower pcs
      //changing bg color and images alpha with time of day
      cloudAlpha=(cloudMaxAlpha-cloudMinAlpha)*sunPctgMidSqrt+cloudMinAlpha;
      //background(100+100*sunOneMinusPctgMid,100,255); //purple
      background(100,100+100*sunOneMinusPctgMid,255); // light blue
    }
    else {
      //sets celestial object's properties to that of the sun
      celestialObject=moon;
      celestialRadius=moonRad;
      celestialAlpha=moonAlpha;
      //NOTE: These two lines to be turned off correspondingly for slightly slower pcs
      //changing bg color and images alpha with time of day
      starAlpha=(starMaxAlpha-starMinAlpha)*sunPctgMidSqrt+starMinAlpha;
      //background(2+198*sunOneMinusPctgMid,2+98*sunOneMinusPctgMid,20+235*sunOneMinusPctgMid); //purple
      background(2+98*sunOneMinusPctgMid,2+198*sunOneMinusPctgMid,20+235*sunOneMinusPctgMid); //light blue
    }

    //////////////////////////////////////////////////////////////////////////////
    //FROG////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////
    //frog time
    frog_time+=20;
    //
    if (cell_initiate==true) {
      cell_time+=cell_timeInc; //the time of the cell moves (animates) when initiated
    }
    else {
      cell_time=-cell_timelineStart; // otherwise reverts back to starting time
    }
    /////////////////////////////////////////////////////////////////////////
    if (cell_time>0) {
      drawCell(cell_time); //after the gap in time, draw the cell animation
    }
    else {
      //resetting initial cell values for another loop
      cell_innerScale099=10;
      cell_alpha=1;
      cell_scaleMin=0;
      cell_scaleMax=1.2f;
      cell_translationMin=200;
      cell_translationMax=-600;
      cell_innerScaleMin=1;
      cell_innerScaleMax=10;
    }
    //editing frog_time, such that it loops
    frog_time-=floor(frog_time/stageTOTALTIME)*stageTOTALTIME; 
    //draw frog animation
    drawFrogCycle();
    ///////////STARS////////////////////////////////////////////////////////////////
    starTime=millis()*starVz-starLoops*(2000+width);//returning starTime for constant loop
    if (starTime>(2000+width)) {
      starTime=0;
      starLoops++; //part of constant loop in starTime
    }
    tint(255,255*starAlpha);
    image(stars,-starTime+width,0); //drawing stars
    tint(255,255);
    /////////DRAW MOON/SUN//////////////////////////////////////////////////////////
    drawSun(sunTime,celestialObject,celestialRadius,celestialAlpha);
    /////Clouds/////////////////////////////////////////////////////////////////////
    cloudTime+=cloudV;//increasing cloud's timer
    tint(255,cloudAlpha*255);
    image(clouds,-cloudTime+width,0); // drawing cloud
    tint(255,255);
    if (cloudTime>(2000+width)) {
      cloudTime=0;
    }
    //LILLYPADS/////////////////////////////////////////////////////////////////////
    lillypadGtime+=lillyTimePlus; //working out time, so loops constantly
    lillypadGeta=(lillypadGtime/lillySPEED-lillyRange-width);
    if (lillypadGeta>0) {
      lillypadGtime=0; //above certain range, timer reverts to 0, loops back
    }
    drawLillypadGroup(lillypadGtime); //drawing lilly pads animation
    //LILLYS///////////////////////////////////////////////////////////////////////
    lillyGtime+=lillyTimePlus; //same4lillypads
    lillyGeta=(lillyGtime/lillySPEED-lillyRange-width);
    if (lillyGeta>0) {
      lillyGtime=0; //same4lillypads
    }
    drawLillyGroup(lillyGtime); //same4lillypads

    //Title Transition - Fading Out///////////////////////////////
    if (millis()<(title_outTime+2000+3000)) {
      fill(0,255-((millis()-(title_outTime+2000))/1000*255));
      //Rectangle's alpha graduates out with time
      noStroke();
      rect(0,0,width,height);
    }
  }
}


//DRAW - TITLE/////////////////////////////////////////////////////
public void drawTitle() {
  noSmooth(); // smoothing in title lags it
  title_time=millis();
  //starting delay
  if (title_time<=title_introLag) {
    background(0); //a glitch that induces non-black initial screen
  }
  else {
    background(100,255,100); //a set background color
  }
  //intro
  for (float i=0; i<=width*2; i+=title_inc) {
    //create strokes tilted at 45*, that change alpha with the following eqn
    //thus partially covering background at times, creating a gradient
    stroke(0,i/(width*2)*((title_introMaxTime+title_introLag-title_time/title_introV)));
    strokeWeight(titleStrokeWeightIn);
    line(i,0,0,i);
  }
  //outro
  if (title_time>title_outTime) {
    //reverse of the intro at a set time
    for (float i=0; i<=width*2; i+=title_inc) {
      stroke(0,(width*2-i)/(width*2)*(title_time-title_outTime)*title_outV);
      strokeWeight(titleStrokeWeightOut);
      line(i,0,0,i);
    }
  }
  tint(255,255); // calls tint in case it has been changed by other functions
  image(titleIMG,0,0);
  smooth(); // return smooth for future additions to code that may use it
}


//DRAW - SUN / MOON/////////////////////////////////////////////////////////////////
public void drawSun(float ttt, PImage object, float radius, float alpha) {
  tint(255,alpha*255);
  //draw object, its y-posn changing with time (ttt)
  //specific object (sun or moon) predefined in void draw
  image(object,width*4/5-radius/2,(height+radius+sunSpaceAdd)*ttt/sunPeriod-radius-sunSpaceAdd/2,radius,radius);
  tint(255,255);
}

//DRAW - LILLYPAD GROUP////////////////////////////////////////////////////////////
public void drawLillypadGroup(float t) {
  noiseSeed(lillypadNoiseS); //takes predetermined noiseSeed - list of values
  lillypadTime=t; //time
  for (int alillypad=alillypadStart; alillypad<=alillypadEnd; alillypad++) {
    //generates a number of lillypads
    float lillypadNoiseY=noise(alillypad+10);
    if ((lillypadNoiseY<0.6f)&&(lillypadNoiseY>0.4f)){
      //slightly avoid center stage, lessens amount of lillypads occupying the space
      lillypadNoiseY=noise(alillypad+11);
      //simply different number means still chance of being there
    }
    float lillypadNoiseR=noise(alillypad+20); //for radius
    float lillypadNoiseA=noise(alillypad+30); //for angle
    float lillypadNoiseLag=noise(alillypad+9); //for spacing throughout stage
    drawLillypad(-lillypadTime/lillySPEED+lillypadNoiseLag*lillypadLagMax,(height+lillypadSpacingAdd)*lillypadNoiseY,lillypadMinRad+(lillypadMaxRad-lillypadMinRad)*lillypadNoiseR,360*lillypadNoiseA);
  }

}
//DRAW - LILLY GROUP////////////////////////////////////////////////////////////////
public void drawLillyGroup(float t) {
  //as4lillypad
  noiseSeed(lillyNoiseS);
  lillyTime=t;
  for (int alilly=alillyStart; alilly<=alillyEnd; alilly++) {
    float lillyNoiseY=noise(alilly+10);
    if ((lillyNoiseY<0.53f)&&(lillyNoiseY>0.47f)){
      lillyNoiseY=noise(alilly+11);
    }
    float lillyNoiseR=noise(alilly+20);
    float lillyNoiseA=noise(alilly+30);
    float lillyNoiseLag=noise(alilly+9);
    drawLilly(-lillyTime/lillySPEED+lillyNoiseLag*lillyLagMax,(height+lillySpacingAdd)*lillyNoiseY,lillyMinRad+(lillyMaxRad-lillyMinRad)*lillyNoiseR,360*lillyNoiseA);
  }
}

//DRAW - LILLYPADS///////////////////////////////////////////////////////////////////
public void drawLillypad(float x, float y, float rad, float ang) {
  pushMatrix();
  translate(x+height,y-lillypadSpacingAdd/2); //translates to desired location
  rotate(ang); //sets rotation for image
  image(lillypad,-rad/2,-rad/2,rad,rad);
  popMatrix(); //matrix so it doesn't build up on itself
}

//DRAW - LILLYS//////////////////////////////////////////////////////////////////////
public void drawLilly(float x, float y, float rad, float ang) {
  //as4lillypads
  pushMatrix();
  translate(x+height,y-lillySpacingAdd/2);
  rotate(ang);
  image(lilly,-rad/2,-rad/2,rad,rad);
  popMatrix();
}


//CELL DRAW////////////////////////////////////////////////////////////////
public void drawCell(float cell_time) {
  pushMatrix();
  smooth();
  if (cell_time<=cell_totalTime) {
    //Handle's cell position over time
    translate(width/2,height/2); //centres cell
    cell_initialdelta=cell_amplitude*sin(radians(cell_time/cell_period));
    if (cell_time>cell_translationStartTime) {
      if (cell_translationTime+cell_translationStartTime>=cell_time) {
        float tranX=((cell_time-cell_translationStartTime)/cell_translationTime*(cell_translationMax-cell_translationMin)+cell_translationMin);
        translate(tranX,0);
      }
      else {
        translate(cell_translationMax,0);
      }
    }
    //Handle's the scale of the cell over time
    if (cell_time>cell_scaleStartTime) {
      if (cell_scaleTime+cell_scaleStartTime>=cell_time) {
        scale((cell_time-cell_scaleStartTime)/cell_scaleTime*(cell_scaleMax-cell_scaleMin)+cell_scaleMin);
      }
      else {
        scale(cell_scaleMax);
      }
      //MIDDLE-POINT=FROG - properties of the central point that represent the frog
      strokeWeight(cell_midPointWeight);
      stroke(0,200,0);
      point(0,0);
      strokeWeight(cell_midPointWeight*0.8f);
      stroke(0,250,0);
      point(0,0);
      //Handle's the pattern of the cell over time
      if (cell_time>cell_innerScaleStartTime) {
        if (cell_innerScaleTime+cell_innerScaleStartTime>=cell_time) {
          cell_innerScale099=((cell_time-cell_innerScaleStartTime)/cell_innerScaleTime*(cell_innerScaleMax-cell_innerScaleMin)+cell_innerScaleMin);
        }
        else {
          cell_innerScale099=(cell_innerScaleMax);
        }
      }
      else {
        cell_innerScale099=(cell_innerScaleMin);
      }
      //fades the cell out once it has ended
      if(cell_time>cell_endTime) {
        cell_alpha=(1-(cell_time-cell_endTime)/cell_alphaOutroTime)*(1);
      }
      //Actually draw the cell
      for (cell_x=0; cell_x<=width; cell_x++) {
        strokeWeight((width-cell_x)/width*cell_maxHeadSize); //changing stroke weight, as it moves away from centre
        stroke(cell_R,cell_G,cell_B,255*cell_alpha); //predefined color
        //placement of the cell's points, in accordance with sin value of time and other variables
        point(cell_x,height/2-cell_initialdelta/cell_headMovement+cell_amplitude*sin(radians(cell_x/cell_lengthi+cell_time/cell_period)));
        rotate(radians(cell_angle)); //creates the rotation for the spiral
        scale(0.99f+cell_innerScale099*0.001f); // dictates the spiral's pattern
      }
    }
  }
  popMatrix();
}

//FROG DRAW//////////////////////////////////////////////////////////////////
public void goFrog(float tranX, float tranY, float time) {
  pushMatrix();

  translate(tranX,tranY); //translates entire frog image accordingly
  timeline_frog=time; //sets time for frog to follow
  if (timeline_frog<100) {
    //dictating when to initiate the cell, and when not to.
    cell_initiate=false;
  } 
  else {
    cell_initiate=true;
  }
  //animating the frog's evolution according to it's preset timeline
  if (timeline_frog>stage0Lag) {
    stage0TaleInc=true;
    if (timeline_frog>stage0Lag) {
      if ((timeline_frog-stage0Lag)<=stage0TaleIncTime) {
        //calculating a percentage, to be used in animating changes in variables
        float stage0TimePctg=(stage0TaleIncTime-(timeline_frog-stage0Lag))/stage0TaleIncTime;
        translate(-stage0TimePctg*(width/2+tale_maxHeadSize),0); //moves the tadpole across
        tale_widthRat=2+stage0TimePctg*(10); //decreases value of, so increases tales width ratio
        tale_lengthi=1-stage0TimePctg*(0.7f); //increases lengthiness of tale
        tale_maxHeadSize=15-stage0TimePctg*(10); //increases maximum head size
        tale_headMovement=2-stage0TimePctg*(1); //increases head movement
        tale_amplitude=15-stage0TimePctg*(15); //increases tale's amplitude
      }
    }
    if (timeline_frog>stage01Lag) {
      if ((timeline_frog-stage01Lag)<=stage01Time) {
        //decreases the tale overall, a reverse of events in stage0
        float stage01TimePctg=(timeline_frog-stage01Lag)/stage01Time;
        tale_lengthi=1-stage01TimePctg*0.7f;
        tale_maxHeadSize=15+stage01TimePctg*25;
        tale_headMovement=2-stage01TimePctg*1;
        tale_widthRat=2+stage01TimePctg*13;
        tale_amplitude=15-stage01TimePctg*15;
      }
    }
    if (timeline_frog>stage1Lag) {
      stage1BkLegs=true;
      //growing the backlegs of the frog
      if ((timeline_frog-stage1Lag)<=stage1Time) {
        float stage1TimePctg=(timeline_frog-stage1Lag)/stage1Time;//time percentage
        legRlegLength=0.01f+stage1TimePctg*(0.1f-0.01f); //increase length of legs
        //legSpeed=5+stage1TimePctg*(35); // lags comp
        leg_translationAngDelta=5+stage1TimePctg*(35);//expand angle between legs
        leg_sinLADamp=0+stage1TimePctg*(2); // increase amplitude
      }
    }
    if (timeline_frog>stage3Lag) {
      stage3eyes=true;
      //growing the eyes of the frog
      if ((timeline_frog-stage3Lag)<=stage3Time) {
        float stage3TimePctg=(timeline_frog-stage3Lag)/stage3Time;
        eyeRad=0+stage3TimePctg*(5); //increasing the radius of the eyes
      }
    }
    if (timeline_frog>stage4Lag) {
      stage4FtLegs=true;
      //growing the front legs of the frog
      if ((timeline_frog-stage4Lag)<=stage4Time) {
        //same as for the back legs of the frog
        float stage4TimePctg=(timeline_frog-stage4Lag)/stage4Time;
        legRarmLength=0+stage4TimePctg*(0.05f-0);
        leg_ARMtranslationAngDelta=30+stage4TimePctg*leg_sinLAD*20;
        leg_armAlpha=0+stage4TimePctg*(255); //fade in the front legs
        leg_sinLADamp=2+stage4TimePctg*(5);
      }
      leg_ARMtranslationAngDelta=30+1*leg_sinLAD*20; //constant swiming rate of the front legs/arms
    }
  }
  //leg - location setup ///// utilises tale variables
  translate(leg_sinLAD*leg_sinLADamp,0);
  if (stage1BkLegs==true){
    for (int legNum=-1; legNum<=1; legNum+=2) { //after creating limb once, reflects it horizontally
      for (int legArm=0; legArm<=1; legArm++) {
        pushMatrix();
        if (legArm==0) {
          leg_translationAng=180+leg_translationAngDelta*legNum; // angle of rotated leg
          legRLength=legRlegLength; //back limbs length
        }
        else {
          if (stage4FtLegs==true) {
            leg_translationAng=leg_ARMtranslationAngDelta*legNum; 
            legRLength=legRarmLength; //dicates position of other limbs
          }
          else {
            legArm++; //if not front legs stage yet, skip
          }
        }
        leg_translationRad=(tale_addHeadSize+tale_maxHeadSize)/2; //calculating radius of legs from body
        //translate legs accordingly to moving frog
        translate(width/2+cos(radians(leg_translationAng))*leg_translationRad,height/2-(tale_initialdelta-tale_initialdelta/tale_headMovement)+sin(radians(leg_translationAng))*leg_translationRad);
        rotate(radians(leg_translationAng)); //rotate legs accordingly
        //leg - setting up variables
        legAlteringDeterminant=(radians(leg_time/legSpeed)); // the sin-wave movement of legs
        leg_sinLAD=sin(legAlteringDeterminant);
        legLength=(cos(legAlteringDeterminant)+1)/2+legLengthMin;
        legVarAmp=-legNum*legAmp/legLength*legRLength;
        //leg - draw up
        for (float i=0; i/legLength<=360; i+=legLength*legIncrementRatio) {
          //when i/leglength is under 360*, to achieve a sin curve, resembling leg
          stroke(100,255,150,255-legArm*(255-leg_armAlpha)); // color
          if(i/legLength>=(355)){
            strokeWeight(7); // making a little blob at the end of the wave
          }
          else {
            if (legArm==0) {
              strokeWeight(5); //default stroke weight for limb, according to front or back
            }
            else {
              strokeWeight(2);
            }
          }
          //Drawing the actual points that make up the leg
          point(i*legRLength,-legVarAmp+legVarAmp*cos(radians(i/legLength)));
        }
        //leg - timing
        leg_time+=leg_timeAdd;
        //vary the leg timing accordingly, for swimming effect (speedup+slowdown)
        if (leg_sinLAD/abs(leg_sinLAD)==-1) {
          leg_time+=leg_timeAdd*leg_LADspeed*(-leg_sinLAD);
        }
        //leg - clean up co-ordinate system
        popMatrix();
      }
    }
  }
  //////////////////////////////////////////////////////////////////////////////
  //tale - initial setups
  if (stage0TaleInc==true) {
    noStroke();
    //tale - location setup
    translate(width/2,height/2); //centres tale
    rotate(radians(180)); //flips tale in opposite direction
    //tale - set up variables
    tale_time=millis();
    tale_initialdelta=tale_amplitude*sin(radians(tale_time/tale_period));
    //tale - draw up
    float widthOnTaleRat=width/tale_widthRat;
    for (taleX=0; taleX<=widthOnTaleRat; taleX+=tale_xIncrement) {
      if (taleX==0) {
        stroke(frog_bodR,frog_bodG,frog_bodB); //preset colors
        strokeWeight(tale_maxHeadSize+tale_addHeadSize); // the first dot = body/head of the frog
      }
      else {
        strokeWeight((widthOnTaleRat-taleX)/widthOnTaleRat*tale_maxHeadSize); //change strokeweight with distance from body
        //change stroke color with distance from body
        stroke(((taleX)/widthOnTaleRat*255),255,((taleX)/widthOnTaleRat*170),(sqrt((widthOnTaleRat-taleX)/widthOnTaleRat)*20));
      }
      point(taleX,-tale_initialdelta/tale_headMovement+tale_amplitude*sin(radians(taleX/tale_lengthi+tale_time/tale_period)));
    }
  }
  //////////////////////////////////////////////////////////////////////////////
  //eyes
  if (stage3eyes==true){
    noStroke();
    fill(frog_eyeR,frog_eyeG,frog_eyeB);//predefined color
    //drawing ellipses for the eyes, calculating placement in accordance with their sizes
    ellipse(-tale_maxHeadSize/2+eyeRad/2,(tale_initialdelta-tale_initialdelta/tale_headMovement)-eyeRad,eyeRad*2,eyeRad*2);
    ellipse(-tale_maxHeadSize/2+eyeRad/2,(tale_initialdelta-tale_initialdelta/tale_headMovement)+eyeRad,eyeRad*2,eyeRad*2);
  }
  popMatrix();
}

//DRAW FROG CYCLE/////////////////////////////////////////////////////////////////
public void drawFrogCycle() {
  if (frog_time<=stage0Lag) {
    //REPEAT INITIAL VARIABLES////////////////////////////////////////////////////
    stage0TaleInc=false;
    stage1BkLegs=false;
    stage3eyes=false;
    stage4FtLegs=false;
    leg_time=0;
    legRlegLength=0.1f;
    legRarmLength=0.05f;
    legAmp=15;
    leg_sinLADamp=0;
    leg_armAlpha=255;
    tale_period=4;
    tale_lengthi=1;
    tale_widthRat=3;
    tale_amplitude=15;
    tale_headMovement=1.5f;
    tale_maxHeadSize=25;
    tale_addHeadSize=tale_maxHeadSize*0.1f;
    frogs_amplitude=frogs_amplitudeU;
    frogs_twineTime=0;
    frogs_twineTimeInc=frogs_twineTimeIncMin;
  }
  //initially translate values at zero
  frog1_translateX=0;
  frog1_translateY=0;
  if (frog_time>=stageNintroLag) {
    if (frog_time<=(stageNintroLag+stageNintroTime)) {
      //frog1 goes up, frog2 comes in to the midle
      frog2_translateX=-(width/1.7f-(width/1.7f)*((frog_time-stageNintroLag)/stageNintroTime));
      frog1_translateY=-(frogs_amplitudeU)*((frog_time-stageNintroLag)/stageNintroTime);
    }
    else {
      frog2_translateX=0;
      frog1_translateY=-frogs_amplitudeU; //setting preset intial y placement
    }
    frog2_translateY=frogs_amplitudeU;
    if (frog_time>=stageNoutroLag) {
      //frogs leaving
      //frogs x value increases out of stage (1.7) gives a bit of space, opposed to (2)
      frog1_translateX=((width/1.7f)*((frog_time-stageNoutroLag)/stageNoutroTime));
      frog2_translateX=((width/1.7f)*((frog_time-stageNoutroLag)/stageNoutroTime));
      //interwining of frogs dictated by a cos value of time
      frog1_translateY=-(cos(radians(frogs_twineTime))*frogs_amplitude);
      frog2_translateY=(cos(radians(frogs_twineTime))*frogs_amplitude);
      frogs_twineTime+=frogs_twineTimeInc;
      //intertwinement gets closer
      frogs_amplitude=frogs_amplitudeU-(frogs_amplitudeU-frogs_amplitudeV)*(frog_time-stageNoutroLag)/stageNoutroTime;
      //interwinement gets faster
      frogs_twineTimeInc=frogs_twineTimeIncMin+((frog_time-stageNoutroLag)/stageNoutroTime)*(frogs_twineTimeIncMax-frogs_twineTimeIncMin);
    }
    //preset colors for certain frog
    frog_eyeR=200;
    frog_eyeG=200;
    frog_eyeB=100;
    frog_bodR=100;
    frog_bodG=255;
    frog_bodB=100;
    //draw frog2 with relevant position and timing
    goFrog(frog2_translateX,frog2_translateY,frog_time);
  }
  //preset colors for certain frog
  frog_eyeR=100;
  frog_eyeG=255;
  frog_eyeB=100;
  frog_bodR=0;
  frog_bodG=255;
  frog_bodB=0;
  //draw frog1 with relevant position and timing
  goFrog(frog1_translateX,frog1_translateY,frog_time);
}



  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "Frog_FINAL" });
  }
}
