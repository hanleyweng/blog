
import hv3

#--------------------------------------------------------------
# Heuristic evaluation function
#--------------------------------------------------------------

# Evaluation function
# piece: The player whose turn it is
# minMax: 0 if trying to minimise score
#		  1 if trying to maximise score
def totalHeuristicValue(_playBoard, currentPlayer, heuristicStrategy):
	
	# Total heuristic value
	totalValue = 0
	
	# Calculate the heuristic values of each player, depending on which heuristic strategy required
	player = 1
	if heuristicStrategy == 0:
		p1 = heuristicValue1(_playBoard, player)
	else:
		p1 = heuristicValue2(_playBoard, player)
	
	player = 2
	if heuristicStrategy == 0:
		p2 = heuristicValue1(_playBoard, player)
	else:
		p2 = heuristicValue2(_playBoard, player)
	
	# The total value heuristic is the difference between both players'
	# scores. Depending on which player's turn it is and whether we are
	# trying to maximise or minimise their score, it will either be p1 - p2
	# or p2 - p1
	
	
	if currentPlayer == 1:
		totalValue = p1 - p2
	else:
		totalValue = p2 - p1

	return totalValue

# Heuristic evaluation function 1
# Calculates the basic heuristic value for a given player
# player: The player number
def heuristicValue1(_playBoard, player):
	value = 0
	b = _playBoard.board

	# Check number of potential horizontal win lines
	for y in range(_playBoard.height):
		for i in range((_playBoard.width - _playBoard.piecesToWin) + 1):
			
			# keep track of how many empty spaces there are
			eCount = 0
			# keep track of how many player pieces there are
			pCount = 0
			
			for x in range(i, i + 4):
				
				# checking the bottom row
				if y == 0:
					if b[x][y] == _playBoard.cellData[0]:
						eCount += 1
					if b[x][y] == player:
						pCount += 1
				
				# checking a row above the bottom, need to ensure that pieces below 
				# are present
				else:
					if b[x][y-1] != _playBoard.cellData[0]:
						if b[x][y] == _playBoard.cellData[0]:
							eCount += 1
						if b[x][y] == player:
							pCount += 1
						
			# if there are 4 in a row of a combination of empty spaces and player pieces	
			if (eCount + pCount == 4) and (pCount != 0):
				value += 1
				
				# if a winning line is found, increase total value by a large amount
				if pCount == 4:
					value += 50
		
	
	# Check number of potential vertical win lines
	for x in range(_playBoard.width):
		for i in range((_playBoard.height - _playBoard.piecesToWin) + 1):
		
			# keep track of how many empty spaces there are
			eCount = 0
			# keep track of how many player pieces there are
			pCount = 0
			
			for y in range(i, i + 4):
				if b[x][y] == _playBoard.cellData[0]:
					eCount += 1
				if b[x][y] == player:
					pCount += 1
			
			if (eCount + pCount == 4) and (pCount != 0):
				value += 1
				if pCount == 4:
					value += 50
				
	
	# Check number of potential diagonal win lines
	
	# Forward slash diag
	for y in range((_playBoard.height - _playBoard.piecesToWin) + 1):
		for x in range((_playBoard.width - _playBoard.piecesToWin) + 1):
			
			# keep track of how many empty spaces there are
			eCount = 0
			# keep track of how many player pieces there are
			pCount = 0
			for i in range(4):
				
				if b[x+i][y+i] == _playBoard.cellData[0]:
					eCount += 1
				if b[x+i][y+i] == player:
					pCount += 1
				
			
			if (eCount + pCount == 4) and (pCount != 0):
				value += 1
				if pCount == 4:
					value += 50
					
	# Backward slash diag
	for y in range((_playBoard.height - _playBoard.piecesToWin) + 1):
		for x in range(_playBoard.width - _playBoard.piecesToWin, _playBoard.width):
			
			# keep track of how many empty spaces there are
			eCount = 0
			# keep track of how many player pieces there are
			pCount = 0
			for i in range(4):
				if b[x-i][y+i] == _playBoard.cellData[0]:
					eCount += 1
				if b[x-i][y+i] == player:
					pCount += 1
			
			if (eCount + pCount == 4) and (pCount != 0):
				value += 1
				if pCount == 4:
					value += 50
	
	return value

# Heuristic evaluation function 2
# Calculates a different heuristic value to evaluation function 1
# player: The player number
def heuristicValue2(_playBoard, player):
	
	value = 0
	b = _playBoard.board
	
	# Check horizontal winning lines
	for y in range(_playBoard.height):
		for i in range((_playBoard.width - _playBoard.piecesToWin) + 1):
			
			line = []
			for x in range(i, i + 4):
				if y == 0:
					line.append(b[x][y])
				else:
					if b[x][y-1] != _playBoard.cellData[0]:
						line.append(b[x][y])					
			
			if len(line) == 4:
				value += calculateScore(line, player)
	
	# Check vertical winning lines
 	for x in range(_playBoard.width):
 		for i in range((_playBoard.height - _playBoard.piecesToWin) + 1):
 			line = []
 			for y in range(i, i + 4):
 				line.append(b[x][y])
 			
 			value += calculateScore(line, player)
 	
 	# Check diagonal winning lines
 	# Forward slash diag
 	for y in range((_playBoard.height - _playBoard.piecesToWin) + 1):
 		for x in range((_playBoard.width - _playBoard.piecesToWin) + 1):
 		
 			line = []
 			for i in range(4):
 				line.append(b[x+i][y+i])
 				
 			value += calculateScore(line, player)
 			
 	# Backward slash diag
 	for y in range((_playBoard.height - _playBoard.piecesToWin) + 1):
 		for x in range(_playBoard.width - _playBoard.piecesToWin, _playBoard.width):
 			
 			line = []
 			for i in range(4):
 				line.append(b[x-i][y+i])
 			
 			value += calculateScore(line, player)
 
	return value
	
def calculateScore(line, player):
	value = 0
	
	# keep track of how many empty spaces there are
	eCount = 0
	
	# keep track of how many player pieces there are
	pCount = 0
	
	# keep track of how many opponent pieces there are
	oCount = 0
	
	# player's pieces in a row
	pStreak = 0
	totalPStreak = 0
	
	# opponent's pieces in a row
	oStreak = 0
	totalOStreak = 0
	
	for space in line:
		
		# Count number of player's pieces in a row
		if space == player:
			pStreak += 1
			
			if pStreak > totalPStreak:
				totalPStreak = pStreak
		else:
			pStreak = 0	
		
		# Count number of opponent's pieces in a  row
		if space == player%2+1:
			oStreak += 1
			
			if oStreak > totalOStreak:
				totalOStreak = oStreak
		else:
			oStreak = 0
				
		if space == 0:
			eCount += 1
		if space == player:
			pCount += 1
		if space == (player%2+1):
			oCount += 1
		
	# If the line is made up of only player pieces and empty spaces	
	if (eCount + pCount == 4) and (pCount != 0):
		value += 1
		
		if pCount == 1:
			value += 1
		
		if pStreak == 2:
			value += 20
		
		if pStreak == 3:
			value += 100
		
 		if pCount == 4:
 			value += 1000
			
	
	# If there are a combination of player, opponent pieces and empty spaces
	if oCount == 3 and pCount == 1:
		value += 300
	
	if oCount == 2 and pCount == 1:
		value += 50
	
		
	return value
	