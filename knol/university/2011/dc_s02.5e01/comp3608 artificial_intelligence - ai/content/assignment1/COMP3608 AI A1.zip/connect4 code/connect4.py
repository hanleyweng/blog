import BoardClass

import PlayerClass

import StatisticalTests

#---------------------------------------------------------------------------------
# Main program
#---------------------------------------------------------------------------------

if __name__ == "__main__":
	
	print_title = """
******************************************************
	Welcome to Connect 4!
******************************************************
"""
	
	print_instructions = """
	Would you like to play against:
	- Strategy A: Minimax algorithm
	- Strategy B: Alpha-beta pruning algorithm
	- Strategy C: Advanced heuristic function

	Type a or b or c and press enter
"""
	
	print print_title
		
	c4 = BoardClass.Board()
	
	
	
	strategy = ''
	depth = 0
	type = 0
	pid = 1
	playing = 0
	
	# Main loop
	while True:
	
		if playing == 0:
			print print_instructions
			while True:
				strategy = raw_input()
				if strategy == 'a' or strategy == 'b' or strategy == 'c':
					break
				else:
					print "Sorry you entered an invalid strategy. Try again"
			
			if strategy == 'a':
				type = 1
				depth = 3
			elif strategy == 'b':
				type = 2
				depth = 4
			elif strategy == 'c':
				type = 3
				depth = 4
			
			# Create AI player
			B = PlayerClass.Player(2, type, depth)
			
			# Create human player
			A = PlayerClass.Player(1, 0, 0)
			
			players = [A, B]
			
			playing = 1
		try :
			
			c4.printOut()
			
			curplayer = players[pid-1]
			var = curplayer.move(c4)
			
			if c4.addPiece(curplayer.id, int(var)) == True:
				if c4.winState() != -1:
					c4.printOut()
					
					# If it's a draw
					if c4.winState() == 0:
						print "The game is a draw!"
					# Someone won
					else:
						print ("Player "+str(c4.winState())+" ["+str(c4.cellDisplay[c4.winState()])+"] is the WINNER! ")
						
						# Let the player who lost go first if game restarts
						pid = pid%2+1
					
					c4.clearBoard()
					var = raw_input("Press Enter to Restart\nType q to quit. ")
					if var == "q":
						break
						
					playing = 0
					
				# Switch turn to the next player	
				else:
					pid = pid%2+1								
			else:
				print "Error, Adding to this Column, Go Again:"
				
					
		except (IndexError,ValueError):
				print "Invalid Entry, Go Again:"