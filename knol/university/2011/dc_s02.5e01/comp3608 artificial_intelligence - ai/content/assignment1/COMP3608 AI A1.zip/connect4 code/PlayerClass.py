import BoardClass

import PlayerAlgorithms

# --------------------------------------------------------------------------------
# Player class
# ______________________________________________________
class Player:
	def __init__(self, _id, _type, _searchDepth) :
		self.id = _id
		self.type = _type # 0=Human, 1=AI (Basic-Strategy-A), 2=AI(Strategy-B), 3=AI(Strategy-C)
		self.typeDisplay = ['Human', 'a', 'b']
		self.cellData = [0,1,2] #characters to be stored - nil, p1, p2
		self.cellDisplay = ['.','O','X'] #characters to be display - nil, p1, p2
		self.c4clone = BoardClass.Board()
		self.searchDepth = _searchDepth
		self.heuristic = [0, 1] # 0=normal heuristic, 1=strategy c heuristic
		
	def move(self, _board) :
		# board/matrix, is displayed with 0,0 being a bottom-left point
		#return move (column) given game-state
		m = _board.board
		if self.type == 0 :
			col = raw_input("P"+str(self.id)+" ["+str(self.cellDisplay[self.id])+"] > ")
			return int(col)-1
		if self.type == 1:
			# Strategy A - Minmax Algorithm with cutoff
			return PlayerAlgorithms.minimaxDecision(_board, self.id, self.searchDepth, self.heuristic[0])
		if self.type == 2:			
			# Strategy B - Alpha beta pruning with cutoff
			return PlayerAlgorithms.alphaBetaSearch(_board, self.id, self.searchDepth, self.heuristic[0])
		if self.type == 3:
			# Strategy C - Mega heuristic
			return PlayerAlgorithms.alphaBetaSearch(_board, self.id, self.searchDepth, self.heuristic[1])
