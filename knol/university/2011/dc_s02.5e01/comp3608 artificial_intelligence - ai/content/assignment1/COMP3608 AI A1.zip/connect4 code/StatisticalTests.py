import BoardClass
import PlayerClass


#---------------------------------------------------------------------------------
# Main program
#---------------------------------------------------------------------------------

def test1():
	
	print "---------------------------------------------------------"
	c4 = BoardClass.Board()
	#self.type = _type # 0=Human, 1=AI (Basic-Strategy-A), 2=AI(Strategy-B)
	
	startingPlayer = 1
	pid = startingPlayer

	winners = []
	
	for i in range (1,6) :
		for j in range (1,6) :
			#j = i
			A = PlayerClass.Player(1,3,i)
			B = PlayerClass.Player(2,2,j)
			players = [A, B]
			
			winners.append(i*100+j)
			
			curCount = 0
			maxCount = 2
			while True:
				try :
					c4.printOut()
					print winners
					curplayer = players[pid-1]
					var = curplayer.move(c4)
					
					if c4.addPiece(curplayer.id, int(var)) == True:
						if c4.winState() == -1:
							pid = pid%2+1
						else :
							c4.printOut()
							winners.append(c4.winState())
							print winners
							c4.clearBoard()
							#Alternate starters
							startingPlayer = startingPlayer%2+1
							pid = startingPlayer
							#Add to Count / End Set
							curCount += 1
							if curCount == maxCount:
								break
				except (IndexError,ValueError):
					print "Error."
			print "---------------------------------------------------------"