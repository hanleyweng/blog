import sys

import PlayerHeuristics

# ---------------------------------------------------------------------------------
# functions used
# ---------------------------------------------------------------------------------

# -------------------------------------------------
# ***************Minimax algorithm*****************
#--------------------------------------------------
# boardState: The current state the board is in
# piece: The player whose turn it is
# depth: The cutoff level in the search tree
#
# returns: The column in which to place the next token
def minimaxDecision(boardState, piece, depth, heur):
	
	currentState = boardState.clone()
	
	# optimal is a 2 element list
	# first element is the value of the next optimal move
	# second element is the column in which to put the piece
	optimal = maxValue(currentState, piece, depth, heur)
	
	# return the column in which to place the piece
	return optimal[1]
	
def maxValue(boardState, piece, depth, heur):
	
	column = -1
	b = boardState.clone()
	
	if depth == 0 or b.winState() != -1:
		v = PlayerHeuristics.totalHeuristicValue(b, piece, heur)
		return [v, column]
	
	v = -sys.maxint
	
	for i in range(boardState.width):
		b = boardState.clone()
		if b.addPiece(piece, i) == True:
			tempv = v
			v = max(v, minValue(b, piece, depth - 1, heur)[0])
			
			# If v changed after applying max(_,_), update column
			if v != tempv:
				column = i
		
	return [v, column]

def minValue(boardState, piece, depth, heur):
	
	column = -1
	b = boardState.clone()
	
	if depth == 0 or b.winState() != -1:
		v = PlayerHeuristics.totalHeuristicValue(b, piece, heur)
		return [v, column]
	
	v = sys.maxint
	
	for i in range(boardState.width):
		b = boardState.clone()
		if b.addPiece(piece%2+1, i) == True:
			tempv = v
			v = min(v, maxValue(b, piece, depth - 1, heur)[0])
			
			# If v changed after applying max(_,_), update column
			if v != tempv:
				column = i

	return [v, column]
	
# ------------------------------------------------------------
# ***************Alpha-beta pruning algorithm*****************
#-------------------------------------------------------------
def alphaBetaSearch(boardState, piece, depth, heur):
	
	currentState = boardState.clone()
	
	optimal = maxValueAB(currentState, piece, depth, heur, -sys.maxint, sys.maxint)
	
	return optimal[1]

def maxValueAB(boardState, piece, depth, heur, alpha, beta):
	
	column = -1
	b = boardState.clone()
	
	if depth == 0 or b.winState() != -1:
		v = PlayerHeuristics.totalHeuristicValue(b, piece, heur)
		return [v, column]
	
	v = -sys.maxint
	
	for x in range(boardState.width):
		b = boardState.clone()
		if b.addPiece(piece, x) == True:
			tempv = v
			v = max(v, minValueAB(b, piece, depth - 1, heur, alpha, beta)[0])
			
			if v != tempv:
				column = x
			
			if v >= beta:
				return [v, column]
			
			alpha = max(alpha, v)

	return [v, column]

def minValueAB(boardState, piece, depth, heur, alpha, beta):
		
	column = -1
	b = boardState.clone()
	
	if depth == 0 or b.winState() != -1:
		v = PlayerHeuristics.totalHeuristicValue(b, piece, heur)
		return [v, column]
	
	v = sys.maxint
	
	for x in range(boardState.width):
		b = boardState.clone()
		if b.addPiece(piece%2+1, x) == True:
			tempv = v
			v = min(v, maxValueAB(b, piece, depth - 1, heur, alpha, beta)[0])
			
			if v != tempv:
				column = x
			
			if v <= alpha:
				return [v, column]
			
			beta = min(beta, v)

	return [v, column]
	