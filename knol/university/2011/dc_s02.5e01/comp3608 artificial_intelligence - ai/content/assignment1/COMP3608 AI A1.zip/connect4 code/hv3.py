


def heuristicValue3(_playBoard, player):
	
	opponent = player%2+1
	hvalue = 0
	Board = _playBoard
	b = Board.board #a matrix, with l-corner piece starting at 0,0
	
	for x in range (Board.width) :
		for y in range (Board.height) :
			cellPiece = b[x][y]
			if cellPiece == player :
				# Perform 8 Directional Check
				
				# Check Horizontal
				# (Potential Wins with this Piece)
				# Generate array (max 3+ to the right and left)
					# that stops when it hits a wall / oponent piece
				# The size of the array is the value of the potential
				# Repeat for Vertical, Diagonal1, Diagonal2
				
				for state in ["horizontal", "vertical", "diagonal1", "diagonal2"] :
					for direction in [-1,1] :
						# Array to the Right (+i), then Left (-i)
						for i in range (1, 4) :
							try:
								if state == "horizontal" :
									col = x+i*direction
									row = y
								if state == "vertical" :
									col = x
									row = y+i*direction
								if state == "diagonal1" :
									col = x+i*direction
									row = y+i*direction
								if state == "diagonal2" :
									col = x-i*direction
									row = y+i*direction
								neighborPiece = b[col][row]
								if neighborPiece != opponent :
									hvalue += 1
								else :
									break
							except (IndexError) :
								break
				
			
			if cellPiece == Board.cellData[0] :
				continue # as no pieces can exist over nothing, can skip to next column
	
	return hvalue


# -----------------------------------------------------------------------------------------
# -----------------------------------------------------------------------------------------
# An Alteration of heuristicValue3
# -----------------------------------------------------------------------------------------
# -----------------------------------------------------------------------------------------

def heuristicValue3a(_playBoard, player):
	
	opponent = player%2+1
	hvalue = 0
	Board = _playBoard
	b = Board.board #a matrix, with l-corner piece starting at 0,0
	
	#seqValue = [0,1,20,100,1000]
	#seqValue = [0,1,4,32,640]
	#seqValue = [0,1,2,4,100]
	#seqValue = [0,1,3,6,100]
	seqValue = [0,1,2,6,100]
	
	if Board.winState() == player :
		return seqValue[4]*7
	if Board.winState() == opponent :
		return -seqValue[4]*7
	
	for x in range (Board.width) :
		for y in range (Board.height) :
			cellPiece = b[x][y]
			if cellPiece == player :
				# Perform 8 Directional Check
				
				# Check Horizontal
				# (Potential Wins with this Piece)
				# Generate array (max 3+ to the right and left)
					# that stops when it hits a wall / oponent piece
				# The size of the array is the value of the potential
				# Repeat for Vertical, Diagonal1, Diagonal2
				
				# Edit: Sequentials in the Array increase it's values
				
				# VALUE ADVANTAGE CHANGES WITH DEPTH
				
				for state in ["horizontal", "vertical", "diagonal1", "diagonal2"] :
					
					friends = [cellPiece]
					for direction in [-1,1] :	
						prevPiece = cellPiece
						for i in range (1, 4) :
							try:
								if state == "horizontal" :
									col = x+i*direction
									row = y
								if state == "vertical" :
									col = x
									row = y+i*direction
								if state == "diagonal1" :
									col = x+i*direction
									row = y+i*direction
								if state == "diagonal2" :
									col = x-i*direction
									row = y+i*direction
								neighborPiece = b[col][row]

								if neighborPiece != opponent :
									if direction == -1 :
										friends.insert(0, neighborPiece)
									if direction == 1 :
										friends.append(neighborPiece)
										
								else :
									break
							except (IndexError) :
								break
					
					sequenceCounts = [0]
					for j in range (len(friends)) :
						if friends[j] == player :
							sequenceCounts[len(sequenceCounts)-1] += 1
						else :
							sequenceCounts.append(0)

					for s in sequenceCounts:
						hvalue += seqValue[min(s, len(seqValue)-1)]
						
						
					
					
			if cellPiece == Board.cellData[0] :
				continue # as no pieces can exist over nothing, can skip to next column
	
	return hvalue


def heuristicValue3b(_playBoard, player):
	
	
	opponent = player%2+1
	hvalue = 0
	Board = _playBoard
	b = Board.board #a matrix, with l-corner piece starting at 0,0
	
	#seqValue = [0,1,20,100,1000]
	seqValue = [0,1,4,32,640]
	#seqValue = [0,1,2,4,100]
	#disValue = [0,1,1,2,3,5,8,13]
	disValue = [0,1,2,3,4,5,6,7]
	
	if Board.winState() == player :
		return seqValue[4]*7
	if Board.winState() == opponent :
		return -seqValue[4]*7
	
	for x in range (Board.width) :
		for y in range (Board.height) :
			cellPiece = b[x][y]
			if cellPiece == player :
				# Perform 8 Directional Check
				
				# Check Horizontal
				# (Potential Wins with this Piece)
				# Generate array (max 3+ to the right and left)
					# that stops when it hits a wall / oponent piece
				# The size of the array is the value of the potential
				# Repeat for Vertical, Diagonal1, Diagonal2
				
				# Edit: Sequentials in the Array increase it's values
				
				
				for state in ["horizontal", "vertical", "diagonal1", "diagonal2"] :
					
					friends = [cellPiece]
					for direction in [-1,1] :	
						prevPiece = cellPiece
						for i in range (1, 4) :
							try:
								if state == "horizontal" :
									col = x+i*direction
									row = y
								if state == "vertical" :
									col = x
									row = y+i*direction
								if state == "diagonal1" :
									col = x+i*direction
									row = y+i*direction
								if state == "diagonal2" :
									col = x-i*direction
									row = y+i*direction
								neighborPiece = b[col][row]

								if neighborPiece != opponent :
									if direction == -1 :
										friends.insert(0, neighborPiece)
									if direction == 1 :
										friends.append(neighborPiece)
									
									if neighborPiece == 0 :
										distance = 0
										# Go down the column
										colc = col
										while b[colc][row] == 0 :
											distance += 1
											if colc == 0:
												break
											colc -= 1
										hvalue += disValue[distance]
										
								else :
									break
							except (IndexError) :
								break
					
					sequenceCounts = [0]
					for j in range (len(friends)) :
						if friends[j] == player :
							sequenceCounts[len(sequenceCounts)-1] += 1
						else :
							sequenceCounts.append(0)
					for s in sequenceCounts:
						hvalue += seqValue[min(s, len(seqValue)-1)]
						
						
					
					
			if cellPiece == Board.cellData[0] :
				continue # as no pieces can exist over nothing, can skip to next column
	
	return hvalue
