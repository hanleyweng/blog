import copy

# --------------------------------------------------------------------------------
# Board class
# --------------------------------------------------------------------------------
class Board:
	def __init__(self) :
		self.width = 7
		self.height = 6
		self.piecesToWin = 4
		self.cellData = [0,1,2] #characters to be stored - nil, p1, p2
		self.cellDisplay = ['.','O','X'] #characters to be display - nil, p1, p2
		
		self.board = []
		self.clearBoard()
		
	def clone(self):
		b = copy.deepcopy(self)
		return b
		
	def clearBoard(self) :
		self.board = []
		for x in range (self.width) :
			column = []
			for y in range (self.height) :
				column.append(self.cellData[0])
			self.board.append(column)
	
	def winState(self) :
		#returns -1 if no-one end game
		#returns 0,1,2 for draw, p1win, p2win
		
		winner = self.winStateHorizontal(self.board)
		if (winner != -1) :
			return winner
		
		winner = self.winStateVertical()
		if (winner != -1) :
			return winner
		
		winner = self.winStateDiagonal()
		if (winner != -1) :
			return winner
			
		#Check Draw State
		for x in range (self.width) :
			if self.board[x][self.height-1] == self.cellData[0]:
				# Game not yet completed
				return -1		
		
		return 0 # Draw
	
	def winStateHorizontal(self, _board) :
		# For each Horizontal, Check for Sequential 4s
		b = _board
		for y in range (len(b[0])) :
			count = 1
			piece = -1
			for x in range (len(b)) :
				if (b[x][y] != piece) :
					piece = b[x][y]
					count = 1
				else :
					count += 1
					if (count == 4) and (piece != self.cellData[0]) :
							return piece
		return -1
		
	def winStateVertical(self) :
		b = self.board
		
		for col in range (self.width) :
			count = 1
			piece = -1
			for y in range (self.height) :
				if (b[col][y] != piece) :
					piece = b[col][y]
					count = 1
				else :
					count += 1
					if (count == 4) and (piece != self.cellData[0]) :
						return piece
		return -1
	
	def winStateDiagonal(self) :
		b = self.board
		# Can cut the head and tail of b2 matrix (since we know we need min 4)
		
		# 'Straighten Out the matrix (going *down (back slash))
		b2 = []
		for x in range (self.width) :
			column = []
			#Head
			for a in range (x) :
				column.append(self.cellData[0])
			#Contents 
			for y in range (self.height) :
				column.append(b[x][y])
			#Tail
			for z in range (self.width - x) :
				column.append(self.cellData[0])			
			b2.append(column)
		
		
		
		winner = self.winStateHorizontal(b2)
		if (winner != -1) :
			return winner
		
		# 'Straighten Out the matrix (going *up (forward slash))
		b2 = []
		for x in range (self.width) :
			column = []
			#Head
			for a in range (self.width - x) :
				column.append(self.cellData[0])
			#Contents 
			for y in range (self.height) :
				column.append(b[x][y])
			#Tail
			for z in range (x) :
				column.append(self.cellData[0])			
			b2.append(column)		
		
		winner = self.winStateHorizontal(b2)
		if (winner != -1) :
			return winner

		return -1
	
	def addPiece(self, _piece, _column) :
		# Returns True if successful, False otherwise
		# Find next free spot in column
		x = _column
		b = self.board
		for y in range (self.height) :
			if (b[x][y] == self.cellData[0]) :
				b[x][y] = _piece
				return True
		return False
		
	def printOut(self) :
		b = self.board
		self.printBorder()
		
		p = ""
		for y in range (len(b[0])-1, -1, -1) :
			for x in range (len(b)) :
				p += str(self.cellDisplay[int(b[x][y])])+" "
			p += "\n"
		p = p.strip()
		print(p)
			
		self.printBorder()
		
		p = ""
		for i in range (len(b)) :
			p += str(i+1)+" "
		print(p)
		
		self.printBorder()
	
	def printBorder(self) :
		border = ""
		for i in range (2*self.width-1) :
			border += "~"
		print border