//
//  DynamicCircle2.mm
//  HelloWorld2d
//
//  Created by Hanley Weng on 23/04/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import "DynamicCircle.h"

#import "Box2DUtils.h"

@implementation DynamicCircle

- (id) init
{
	if (self = [super init])
	{
		[self setType:@"DynamicCircle"];
		[self setDead:FALSE];
		
		// Sprite
		PXTextureData *textureData = [PXTextureData textureDataWithContentsOfFile:@"InkBall.png"];
		PXTexture *image = [[PXTexture alloc] initWithTextureData:textureData];
		[image setSmoothing:TRUE];
		[image setScale:0.7f];
		[image setAnchorWithX:0.5f andY:0.5f];
		
		[self addChild:image];
	}
	return self;
}

- (void) dealloc
{
	[super dealloc];
}

- (void) initialize:(b2World *)_myWorld
{
	// World
	[super initialize:_myWorld];
	
	// Shape
	b2CircleShape circleShape;
	circleShape.m_radius = PointsToMeters(12.0f);
	
	// Body
	myBody = [Box2DUtils dynamicBodyInWorld:myWorld 
							   withFriction:0.7f
								restitution:0.3f
									  shape:&circleShape];
	
	myBody->SetTransform(b2Vec2_px2m(100.0f, 100.0f), 0.0f);
	
	myBody->SetUserData(self);
	
}

- (void) setX:(float)_x andY:(float)_y
{
	myBody->SetTransform(b2Vec2_px2m(_x, _y), 0.0f);
}


@end
