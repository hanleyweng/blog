//
//  StaticBlock.h
//  HelloWorld2d
//
//  Created by Hanley Weng on 24/04/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import "Pixelwave.h"
#import "Box2D.h"

#import "Actor.h"

@interface StaticBlock : Actor
{	
	float targetX, targetY;
	bool touchDisabled;
	bool touchCausesDeath;
}
- (void) initialize:(b2World *)_myWorld;
- (void) setTargetX:(float)_targetX targetY:(float)_targetY;
- (void) setX:(float)_x andY:(float)_y;
- (float) getTargetX;
- (float) getTargetY;

- (void) setTouchDisabled:(BOOL)_isTouchDisabled;
- (void) setTouchCausesDeath:(BOOL)_touchCausesDeath;

@end
