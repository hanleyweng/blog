//
//  HelloWorld2dRoot.m
//  HelloWorld2d
//
//  Created by Hanley Weng on 19/04/11.
//  Copyright Hanley Weng. 2011. All rights reserved.
//

#import "HelloWorld2dRoot.h"

#import "State_Actor.h"
#import "State_Menu.h"
#import "State_Play.h"
#import "State_CreateAndSave.h"

@implementation HelloWorld2dRoot

- (void) dealloc
{
	[self removeEventListenerOfType:PX_EVENT_ENTER_FRAME listener:PXListener(onEnterFrame)];
	
	[curState release];
	curState = NULL;
	
	[super dealloc];
}

- (void) initializeAsRoot
{	
	self.stage.backgroundColor = 0x45FFFF;
	
	[self addEventListenerOfType:PX_EVENT_ENTER_FRAME listener:PXListener(onEnterFrame)];
	
	curState = [[State_Menu alloc] init];
	[self addChild:curState];
	[curState release];
	[curState initializeAsRoot];
	
}

- (void) onEnterFrame
{
	if (curState != NULL) {
		NSString *curDesiredState = [curState desiredState];
		//NSLog(@"%@", curDesiredState);
		if (curDesiredState != NULL) {
			if ([curDesiredState isEqualToString: @"State_Menu"]) {
				[self removeChild:curState];
				curState = nil;
				curState = [[State_Menu alloc] init];
				[self addChild:curState];
				[curState release];
				[curState initializeAsRoot];
			}
			if ([curDesiredState isEqualToString: @"State_Play"]) {
				[self removeChild:curState];
				curState = nil;
				curState = [[State_Play alloc] init];
				[self addChild:curState];
				[curState release];
				[curState initializeAsRoot];
			}
			if ([curDesiredState isEqualToString: @"State_CreateAndSave"]) {
				[self removeChild:curState];
				curState = nil;
				curState = [[State_CreateAndSave alloc] init];
				[self addChild:curState];
				[curState release];
				[curState initializeAsRoot];
			}
		}
	}
}

@end
