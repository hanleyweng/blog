//
//  State_CreateAndSave.h
//  HelloWorld2d
//
//  Created by Hanley Weng on 9/05/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Pixelwave.h"
#import "Box2D.h"
#import "Box2DListeners.h"

#import "State_Actor.h"
#import "MovableSprite.h"
#import "DynamicCircle.h"
#import "StaticBlock.h"

#import "GridEditor.h"

@interface State_CreateAndSave : State_Actor <UIAccelerometerDelegate>
{
	// State
	PXSimpleButton *btn_State_Menu;
	
	// Physics ---------------------------------------
	b2World *physicsWorld;
	float timeStep;
	int velocityIterations, positionIterations;
	bool worldIsPaused;
	float count;
	
	// Listeners
	DestructionListener *destructionListener;
	ContactListener *contactListener;
	
	// Scene -----------------------------------------
	//PXSimpleButton *plusBtn;
	PXSimpleButton *saveBtn;
	float targetX, targetY;	
	MovableSprite *startPt, *endPt;
	DynamicCircle *hero;
	PXTextField *atxtfield;
	GridEditor *grid;
	StaticBlock *gridSBlocks[NUMCOLS][NUMROWS];
}

- (void) initializeAsRoot;
- (void) accelerometer:(UIAccelerometer *)anAccelerometer didAccelerate:(UIAcceleration *)anAcceleration;

@end
