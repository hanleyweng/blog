//
//  State_Actor.h
//  HelloWorld2d
//
//  Created by Hanley Weng on 9/05/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import "Pixelwave.h"

//#define MetersToPoints(_meters_) ((_meters_) * POINTS_PER_METER)

#define myDistance(_x1_,_y1_,_x2_,_y2_) (sqrt((_x1_-_x2_)*(_x1_-_x2_) + (_y1_-_y2_)*(_y1_-_y2_)))
#define GRAVITYRATIO 0.65f

@interface State_Actor : PXSprite
{
	NSString * type;
	NSString * desiredState;
}

- (void) initializeAsRoot;

- (BOOL) isType:(NSString *)_type;
- (void) setType:(NSString *)_type;

- (NSString *) desiredState;
- (BOOL) isDesiredState:(NSString *)_desiredState;
- (void) setDesiredState:(NSString *)_desiredState;

@end
