//
//  MovableSprite.h
//  HelloWorld2d
//
//  Created by Hanley Weng on 15/05/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import "Pixelwave.h"

#import "Actor.h"

// SAME AS STATICBLOCK - EXCEPT BODY->ACTIVE = FALSE

@interface MovableSprite : Actor
{
	float targetX, targetY;
}

- (void) initialize:(b2World *)_myWorld withImage:(NSString *)_image;
- (void) initialize:(b2World *)_myWorld;

- (void) setX:(float)_x andY:(float)_y;
- (void) setTargetX:(float)_targetX targetY:(float)_targetY;
- (float) getTargetX;
- (float) getTargetY;


@end
