//
//  GridEditor.mm
//  HelloWorld2d
//
//  Created by Hanley Weng on 22/05/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import "GridEditor.h"

#import "Box2DUtils.h"

#import "StaticBlock.h"
#import "MovableSprite.h"
#import "Actor.h"

@implementation GridEditor

- (void) dealloc
{

	[self removeEventListenerOfType:PX_TOUCH_EVENT_TOUCH_MOVE listener:PXListener(onTouchMove:)];
	[self removeEventListenerOfType:PX_EVENT_ENTER_FRAME listener:PXListener(onEnterFrame)];
	[super dealloc];
}

- (int) matrixValueAtX:(int)_x AtY:(int)_y
{
	return matrix[_x][_y];
}

// ----------------------------------------------------------------------------------

- (id) init
{
	if (self = [super init])
	{
		[self setType:@"GridEditor"];
		
		// Sprite (self)
		PXTextureData *textureData = [PXTextureData textureDataWithContentsOfFile:@"grid30.png"];
		PXTexture *image = [[PXTexture alloc] initWithTextureData:textureData];
		[image setSmoothing:TRUE];
		[image setScale:1.0f];
		[image setAnchorWithX:0.0f andY:0.0f];
		
		[self addChild:image];
		
		[self addEventListenerOfType:PX_TOUCH_EVENT_TOUCH_MOVE listener:PXListener(onTouchMove:)];
		[self addEventListenerOfType:PX_EVENT_ENTER_FRAME listener:PXListener(onEnterFrame)];
		
		// Initalize a matrix
		for (int x=0; x<NUMCOLS; x++) {
			for (int y=0; y<NUMROWS; y++) {
				//int value = x*100+y;
				int value = 0;
				matrix[x][y] = value;
			}
		}
		
		/*
		// Initialize Display Matrix
		for (int x=0; x<NUMCOLS; x++) {
			for (int y=0; y<NUMROWS; y++) {
				//if (matrix[x][y] == 1) {
					
					PXTextureData *blockTextureData = [PXTextureData textureDataWithContentsOfFile:@"BlankIcon.png"];
					PXTexture *block = [[PXTexture alloc] initWithTextureData:blockTextureData];
					[block setSmoothing:TRUE];
					[block setScale:0.50f];
					[block setAnchorWithX:0.5f andY:0.5f];
					block.x = x*GRIDGAP+GRIDGAP/2+1;
					block.y = y*GRIDGAP+GRIDGAP/2+1;
					
					displayMatrix[x][y] = block;
					[self addChild:block];
					
				//}
			}
		}
		 */
		
		
	}

	return self;
}

- (void) initialize:(b2World *)_myWorld
{
	// World
	[super initialize:_myWorld];
	
	// Shape
	b2PolygonShape box;
	box.SetAsBox(PointsToMeters(1.0f), PointsToMeters(1.0f), b2Vec2(0.0f, 0.0f), 0.0f);
	// Body
	myBody = [Box2DUtils staticBodyInWorld:myWorld
							  withFriction:1.0f
							   restitution:0.8f
									 shape:&box];
	myBody->SetTransform(b2Vec2_px2m(0.0f, 0.0f), 0.0f);
	myBody->SetUserData(self);
	myBody->SetActive(FALSE);
	
}

- (void) updateMatrixFromEvent:(PXTouchEvent *)event
{
	if ([self isTouchedDown]) {
		int curGridX = event.stageX/GRIDGAP;
		int curGridY = event.stageY/GRIDGAP;
		if ((curGridX != prvGridX) || (curGridY != prvGridY)) {
			//NSLog(@"grid touched down: %d, %d", curGridX, curGridY);
			int x = curGridX;
			int y = curGridY;
			matrix[x][y] = !matrix[x][y];
			
			prvGridX = curGridX;
			prvGridY = curGridY;
		}
	}
}

- (void) onTouchMove:(PXTouchEvent *)event
{	
	[self updateMatrixFromEvent:event];
}

- (void) onTouchDown:(PXTouchEvent *)event
{
	[self updateMatrixFromEvent:event];
	// Interited From Super
	[super onTouchDown:event];
	NSLog(@"grid touched down");
}

- (void) onTouchUp:(PXTouchEvent *)event
{
	prvGridX = nil;
	prvGridY = nil;
	// Interited From Super
	[super onTouchUp:event];
	NSLog(@"grid touched up");	
}



- (void) onEnterFrame 
{
	/*
	for (int x=0; x<NUMCOLS; x++) {
		for (int y=0; y<NUMROWS; y++) {
			// If there shouldn't be a block, but there's one, delete.
			if (matrix[x][y] == 0) {
				if (displayMatrix[x][y] != NULL) {
					PXTexture *block = (PXTexture *) displayMatrix[x][y];
					[self removeChild:block];
					displayMatrix[x][y] = NULL;
				}
			}
			
			// If there should be a block, but there's none, add.
			if (matrix[x][y] == 1) {
				if (displayMatrix[x][y] == NULL) {
					PXTextureData *blockTextureData = [PXTextureData textureDataWithContentsOfFile:@"BlankIcon.png"];
					PXTexture *block = [[PXTexture alloc] initWithTextureData:blockTextureData];
					[block setSmoothing:TRUE];
					[block setScale:0.50f];
					[block setAnchorWithX:0.5f andY:0.5f];
					block.x = x*GRIDGAP+GRIDGAP/2+1;
					block.y = y*GRIDGAP+GRIDGAP/2+1;
					
					displayMatrix[x][y] = block;
					[self addChild:block];
				}
			}
		}
	}
	 */
}

@end
