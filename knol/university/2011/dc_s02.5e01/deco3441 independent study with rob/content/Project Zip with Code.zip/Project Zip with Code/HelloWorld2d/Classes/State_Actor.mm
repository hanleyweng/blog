//
//  State_Actor.mm
//  HelloWorld2d
//
//  Created by Hanley Weng on 9/05/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import "State_Actor.h"

@implementation State_Actor

- (void) initializeAsRoot
{
}

/*
- (id) init
{
	if (self = [super init])
	{
	}

	return self;
}
 */

- (void) dealloc
{
	[super dealloc];
}

- (void) setType:(NSString *)_type
{
	type = _type;
}

- (BOOL) isType:(NSString *)_type
{
	if ([type isEqualToString:_type]) {
		return TRUE;
	}
	return FALSE;	
}

- (NSString *) desiredState
{
	return desiredState;
}

- (void) setDesiredState:(NSString *)_desiredState
{
	desiredState = _desiredState;
}

- (BOOL) isDesiredState:(NSString *)_desiredState
{
	if ([desiredState isEqualToString:_desiredState]) {
		return TRUE;
	}
	return FALSE;
}

@end
