//
//  MovableSprite.m
//  HelloWorld2d
//
//  Created by Hanley Weng on 15/05/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import "MovableSprite.h"

#import "Box2DUtils.h"

@implementation MovableSprite

- (void) dealloc
{	
	[self removeAllEventListeners]; //
	[self removeEventListenerOfType:PX_EVENT_ENTER_FRAME listener:PXListener(onEnterFrame)];
	[super dealloc];
}

- (void) setX:(float)_x andY:(float)_y {
	myBody->SetTransform(b2Vec2_px2m(_x,_y), 0.0f);
}

- (void) setTargetX:(float)_targetX targetY:(float)_targetY {
	targetX = _targetX;
	targetY = _targetY;
}

- (float) getTargetX {
	return targetX;
}

- (float) getTargetY {
	return targetY;
}

// ----------------------------------------------------------------------------------

- (id) init
{
	if (self = [super init])
	{
		// self setType
		[self setType:@"MovableSprite"];
		
		[self addEventListenerOfType:PX_EVENT_ENTER_FRAME listener:PXListener(onEnterFrame)];
		
	}
	return self;
}

- (void) initialize:(b2World *)_myWorld
{
	[self initialize:_myWorld withImage:@"Icon_i.png"];
}

- (void) initialize:(b2World *)_myWorld withImage:(NSString *)_image
{
	// Self Sprite
	PXTextureData *textureData = [PXTextureData textureDataWithContentsOfFile:_image];
	PXTexture *image = [[PXTexture alloc] initWithTextureData:textureData];
	[image setSmoothing:TRUE];
	[image setAnchorWithX:0.5f andY:0.5f];
	
	[self addChild:image];
	
	// ---------------------------------------------------------------------------------------
	
	// World
	[ super initialize:_myWorld];
	
	// Shape
	b2PolygonShape square;
	square.SetAsBox(PointsToMeters(1.0f), PointsToMeters(1.0f), b2Vec2(0.0f, 0.0f), 0.0f);
	
	// Body
	myBody = [Box2DUtils staticBodyInWorld:myWorld
							  withFriction:1.0f
							   restitution:0.8f
									 shape:&square];
	myBody->SetTransform(b2Vec2_px2m(STAGEWIDTH/2, STAGEHEIGHT/2), 0.0f);
	myBody->SetUserData(self);
	myBody->SetActive(FALSE); // Disables influence with other bodys
	
	// TargetX,Y
	targetX = (CGFloat) (myBody->GetPosition().x * POINTS_PER_METER);
	targetY = (CGFloat) (myBody->GetPosition().y * POINTS_PER_METER);
}

- (void) onEnterFrame
{
	if (myBody != NULL) {
		CGFloat bx = (CGFloat) (myBody->GetPosition().x * POINTS_PER_METER);
		CGFloat by = (CGFloat) (myBody->GetPosition().y * POINTS_PER_METER);
		
		bx += (targetX - bx) * 0.1f;
		by += (targetY - by) * 0.1f;
		
		myBody->SetTransform(b2Vec2_px2m(bx,by),0.0f);
	}
}

@end
