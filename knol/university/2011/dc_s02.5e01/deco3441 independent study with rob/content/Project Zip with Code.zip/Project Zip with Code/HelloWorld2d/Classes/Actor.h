//
//  Actor.h
//  HelloWorld2d
//
//  Created by Hanley Weng on 24/04/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import "Pixelwave.h"
#import "Box2d.h"

# define STAGEWIDTH 480
# define STAGEHEIGHT 320

@interface Actor : PXSprite
{
	BOOL isDead;
	bool touchedDown;
	NSString * type;
	
	b2Body *myBody;
	b2World *myWorld;
	
}
- (NSString *) getType;
- (BOOL) isType:(NSString *)_type;
- (void) setType:(NSString *)_type;

- (BOOL) isTouchedDown;

- (BOOL) isDead;
- (void) setDead:(BOOL)_isDead;

- (void) onTouchDown:(PXTouchEvent *)event;
- (void) onTouchUp:(PXTouchEvent *)event;

- (void) nullifyBody;

- (void) initialize:(b2World *)_myWorld;



@end
