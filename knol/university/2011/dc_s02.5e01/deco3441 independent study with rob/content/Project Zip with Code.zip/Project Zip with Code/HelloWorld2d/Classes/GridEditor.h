//
//  GridEditor.h
//  HelloWorld2d
//
//  Created by Hanley Weng on 22/05/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import "Pixelwave.h"
#import "Box2D.h"

#import "Actor.h"
#import "StaticBlock.h"

# define GRIDGAP 30
# define NUMCOLS 16 //ceil(STAGEWIDTH/GRIDGAP)
# define NUMROWS 11 //ceil(STAGEHEIGHT/GRIDGAP)

@interface GridEditor : Actor
{
	int matrix[NUMCOLS][NUMROWS];
	//PXTexture * displayMatrix[NUMCOLS][NUMROWS];
	int prvGridX, prvGridY;
}

- (void) initialize:(b2World *)_myWorld;
- (int) matrixValueAtX:(int)_x AtY:(int)_y;

- (void) updateMatrixFromEvent:(PXTouchEvent *)event;

@end
