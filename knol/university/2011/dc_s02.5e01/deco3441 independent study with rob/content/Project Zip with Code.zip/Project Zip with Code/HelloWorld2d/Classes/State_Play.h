//
//  State_Play.h
//  HelloWorld2d
//
//  Created by Hanley Weng on 8/05/11.
//  Copyright 2011 Student. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Pixelwave.h"
#import "Box2D.h"
#import "Box2DListeners.h"

#import "State_Actor.h"
#import "MovableSprite.h"

@class DynamicCircle;
@class StaticBlock;
@class Actor;

@interface State_Play : State_Actor <UIAccelerometerDelegate>
{
	// State
	PXSimpleButton *btn_State_Menu;
	
	// Physics ---------------------------------------
	b2World *physicsWorld;
	bool worldIsPaused;
	float count;
	float timeStep;
	int velocityIterations, positionIterations;
	
	// Listeners
	DestructionListener *destructionListener;
	ContactListener *contactListener;
	
	// Scene -----------------------------------------
	float targetX, targetY;
	MovableSprite *startPt, *endPt;
	DynamicCircle *hero;
	PXTextField *atxtfield;
}

- (void) initializeAsRoot;
- (void) accelerometer:(UIAccelerometer *)anAccelerometer didAccelerate:(UIAcceleration *)anAcceleration;

- (void) loadLastState;

@end
