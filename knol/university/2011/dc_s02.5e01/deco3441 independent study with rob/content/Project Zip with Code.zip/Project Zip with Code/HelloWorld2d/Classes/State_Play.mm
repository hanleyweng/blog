//
//  State_Play.m
//  HelloWorld2d
//
//  Created by Hanley Weng on 8/05/11.
//  Copyright 2011 Student. All rights reserved.
//

#import "State_Play.h"

#import "Box2DUtils.h"
#import "PKBox2DDebugLayer.h"

#import "DynamicCircle.h"
#import "StaticBlock.h"

#import "ASIHTTPRequest.h"
#import "JSON/JSON.h"

@interface State_Play(Private)
- (void) createScene;
@end

@implementation State_Play

- (void) dealloc
{
	//[self.stage addEventListenerOfType:PX_TOUCH_EVENT_TOUCH_MOVE listener:PXListener(onTouchMove:)];
	//[self.stage removeEventListenerOfType:PX_TOUCH_EVENT_TOUCH_MOVE listener:PXListener(onTouchMove:)];
	//[self removeAllEventListeners];
	//[self.stage removeAllEventListeners];
	
	b2Body *node = physicsWorld->GetBodyList();
	while (node) {
		b2Body *b = node;
		node = node->GetNext();
		
		if (b->GetUserData() != NULL) {
			
			Actor *sprite = (Actor *) b->GetUserData();
			[sprite nullifyBody];
			[self removeChild:sprite];
			b->SetUserData(NULL);
			// Above lines of code 'works'ish - just have to make sure sprite covers entire body.
		}	
	}
	
	
	
	delete physicsWorld;
	physicsWorld = NULL;
	
	// Unload all the listeners
	if (destructionListener)
	{
		delete destructionListener;
		destructionListener = NULL;
	}
	
	if (contactListener)
	{
		delete contactListener;
		contactListener = NULL;
	}
	
	[btn_State_Menu release];
	btn_State_Menu = nil;
	
	[[UIAccelerometer sharedAccelerometer] setDelegate:nil];	
	
	[super dealloc];
		
}	

- (void) initializeAsRoot
{
	
	[super initializeAsRoot];
	[self setType:@"State_Play"];
	
	self.stage.frameRate = 60.0;
	self.stage.nativeView.multipleTouchEnabled = NO;
	
	
	timeStep = 1.0f / self.stage.frameRate;
	velocityIterations = 10;
	positionIterations = 10;
	
	b2Vec2 gravity(0.0f, GRAVITY);
	bool doSleep = false;
	physicsWorld = new b2World(gravity, doSleep);
	
	
	destructionListener = NULL;
	contactListener = NULL;
	
	// Debug Graphics Layer
	/*
	PKBox2DDebugLayer *layer = [PKBox2DDebugLayer new];
	layer.physicsWorld = physicsWorld;
	layer.scale = POINTS_PER_METER;
	layer.touchPicking = YES; // <- Comment out this line to disable object picking
	
	[self addChild:layer]; //
	[layer release];
	*/
	[self createScene];
	[self addEventListenerOfType:PX_EVENT_ENTER_FRAME listener:PXListener(onEnterFrame)];
	
}

// -----------------------------------------------------------------------------------------------------------------------------

- (void) loadLastState
{
	// Mark All Current Blocks for Deletion
	for (b2Body *b = physicsWorld->GetBodyList(); b; b=b->GetNext()) {
		if (b->GetUserData() != NULL) {
			Actor *myActor = (Actor *)b->GetUserData();
			if ([myActor isType:@"StaticBlock"]) {
				[myActor setDead:TRUE];
			}
		}
	}
	
	// Load New Items
	NSString *loadUrl = @"http://hello-o.appspot.com/?action=getData&limit=1";
	
	NSURL *url = [NSURL URLWithString:loadUrl];
	ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
	[request startSynchronous];
	NSError *error = [request error];
	if (!error) {
		NSString *response = [request responseString];
		//NSLog(@"%@", response);
		
		NSDictionary *results = [response JSONValue];
		NSLog(@"%@", results);
		
		// StartPt
		NSDictionary *startPtInfo = [results objectForKey:@"startPt"];
		float _spx = [[startPtInfo objectForKey:@"x"] floatValue];
		float _spy = [[startPtInfo objectForKey:@"y"] floatValue];
		startPt = [MovableSprite new];
		[startPt initialize:physicsWorld withImage:@"StartIconTransparent.png"];
		[startPt setX:_spx andY:_spy];
		[startPt setTargetX:_spx targetY:_spy];
		[self addChild:startPt];
		
		// EndPt
		NSDictionary *endPtInfo = [results objectForKey:@"endPt"];
		float _epx = [[endPtInfo objectForKey:@"x"] floatValue];
		float _epy = [[endPtInfo objectForKey:@"y"] floatValue];
		endPt = [MovableSprite new];
		[endPt initialize:physicsWorld withImage:@"StarIconTransparent.png"];
		[endPt setX:_epx andY:_epy];
		[endPt setTargetX:_epx targetY:_epy];
		[self addChild:endPt];
		
		// Blocks
		NSArray *actors = [results objectForKey:@"actor"]; 
		for (NSDictionary *actor in actors) {
			
			float x = 0.0f;
			float y = 0.0f;
			for (id key in actor) {
				
				if ( [key isEqualToString: @"x"]) {
					x = [ [ actor objectForKey:key ] floatValue ];
				}
				if ( [key isEqualToString: @"y"]) {
					y = [ [ actor objectForKey:key ] floatValue ];
				}
			}
			
			StaticBlock * dba2 = [StaticBlock new];
			[dba2 initialize:physicsWorld];
			[self addChild:dba2];
			[dba2 setTargetX:x targetY:y];
			
		}
		
	}
}

- (void) createScene
{
	float stageWidth = self.stage.stageWidth;
	float stageHeight = self.stage.stageHeight;
	
	// BACKGROUND IMAGE
	PXTextureData *bgTextureData = [PXTextureData textureDataWithContentsOfFile:@"BgNotepad.jpg"];
	PXTexture *bgTexture = [[PXTexture alloc] initWithTextureData:bgTextureData];
	[bgTexture setAnchorWithX:0.0f andY:0.0f];
	bgTexture.x=0.0f;
	bgTexture.y=0.0f;
	[self addChild:bgTexture];
	bgTextureData = [PXTextureData textureDataWithContentsOfFile:@"TransparentBg.png"];
	bgTexture = [[PXTexture alloc] initWithTextureData:bgTextureData];
	[bgTexture setAnchorWithX:0.0f andY:0.0f];
	bgTexture.x=0.0f;
	bgTexture.y=0.0f;
	[self addChild:bgTexture];
	//Bounds
	PXRectangle *bounds = [PXRectangle rectangleWithX:0.0f andY:0.0f andWidth:stageWidth andHeight:stageHeight];
	[Box2DUtils staticBorderInWorld:physicsWorld rect:bounds thickness:10.0f];
	
	
	// load last state
	[self loadLastState];
	
	// .h vars
	worldIsPaused = FALSE;
	count = 0;
	atxtfield = [PXTextField new];
	[self addChild:atxtfield];
	
	// EVENTS
		
	// Create some Dummy objects
	hero = [DynamicCircle new];
	[hero initialize:physicsWorld];
	[hero setX:[startPt getTargetX] andY:[startPt getTargetY]];
	[self addChild:hero];
	 
	// State_Menu Button
	PXTextureData *textureData3 = [PXTextureData textureDataWithContentsOfFile:@"StopIcon.png"];
	PXTexture *texture3 = [[PXTexture alloc] initWithTextureData:textureData3];
	[texture3 setAnchorWithX:0.0f andY:0.0f];
	btn_State_Menu = [[PXSimpleButton alloc] initWithUpState:texture3 downState:texture3 hitTestState:texture3];
	btn_State_Menu.x = 0.0f;
	btn_State_Menu.y = 0.0f;
	[self addChild:btn_State_Menu];
	[btn_State_Menu addEventListenerOfType:PX_TOUCH_EVENT_TOUCH_UP listener:PXListener(stateMenuPressed:)];
	
	// Delete Button (Fake Area)
	/*
	PXTextureData *textureData;
	PXTexture *texture;
	textureData = [PXTextureData textureDataWithContentsOfFile:@"Icon.png"];
	texture = [[PXTexture alloc] initWithTextureData:textureData];
	[texture setAnchorWithX:1.0f andY:1.0f];
	
	PXTexture *texture2 = [[PXTexture alloc] initWithTextureData:textureData];
	[texture2 setAnchorWithX:1.0f andY:0.0f];
	texture2.x = self.stage.stageWidth;
	texture2.y = 0.0f;
	[self addChild:texture2];
	*/
	
	// start accelerometer
	[[UIAccelerometer sharedAccelerometer] setDelegate:self];

}

- (void) stateMenuPressed: (PXTouchEvent *) event
{
	[self setDesiredState:@"State_Menu"];
}

- (void) destroyBodies
{
	b2Body *node = physicsWorld->GetBodyList();
	while (node) {
		b2Body *b = node;
		node = node->GetNext();
		
		if (b->GetUserData() != NULL) {
			
			Actor *sprite = (Actor *) b->GetUserData();
			if ([sprite isDead]) {
				
				// NOTE: Can't figure out deletion (of b2body). Faking it. //Crashes if body is destroyed when touched. (Possibly Joins). (Possibly References). //If no 'nice' solution in the end. Simply delete latently, when we know user has reset their touch points.
				b->SetTransform(b2Vec2_px2m(0.0f, 50.0f), 0.0f);
				[sprite setDead:FALSE];
				// TEMPORARY CODE: If StaticBlock, change the target to stop it moving!
				if ([sprite isType:@"StaticBlock"]) {
					StaticBlock *spriteb = (StaticBlock *) sprite;
					[spriteb setTargetX:0.0f targetY:0.0f];
					[sprite setDead:TRUE];
				}
				//[sprite nullifyBody];
				//[self removeChild:sprite];
				//b->SetUserData(NULL);
				// Above lines of code 'works'ish - just have to make sure sprite covers entire body.
			}
		}	
	}
}


- (void) onEnterFrame
{	
	// Step
	if (!worldIsPaused) {
		physicsWorld->Step(timeStep, velocityIterations, positionIterations);
		count += 1/self.stage.frameRate;
	}
	
	// Scene Elements
	for (b2Body *b = physicsWorld->GetBodyList(); b; b=b->GetNext())
	{
		CGFloat bx = (CGFloat) (b->GetPosition().x * POINTS_PER_METER);
		CGFloat by = (CGFloat) (b->GetPosition().y * POINTS_PER_METER);
		
		if (b->GetUserData() != NULL) {
			
			Actor *spritet = (Actor *)b->GetUserData();
			spritet.x = bx;
			spritet.y = by;
			spritet.rotation = (CGFloat) (b->GetAngle() * 180 / M_PI);
			
			//Set Target if it's a dummy block
			/*
			if ([spritet isType:@"StaticBlock"]) {
				StaticBlock *spriteb = (StaticBlock *) spritet;
				if ([spriteb isTouchedDown]) {
					[spriteb setTargetX:targetX targetY:targetY];
				}
			}
			*/
			
			//Deleting Elements
			/*
			if (bx>self.stage.stageWidth*0.8f) {
				if (by<self.stage.stageHeight*0.2f) {
					if (![spritet isTouchedDown]) {
						[spritet setDead:TRUE];
					}
				}
			}
			 */
			
		}
	}
	
	// Hero hitTest EndPt
	float d = myDistance(endPt.x,endPt.y,hero.x,hero.y);
	if (d<20) {
		if (worldIsPaused == FALSE ) {
			worldIsPaused = TRUE;
			
			PXTextureData *textureData = [PXTextureData textureDataWithContentsOfFile:@"ScorePopup.png"];
			PXTexture *image = [[PXTexture alloc] initWithTextureData:textureData];
			[image setSmoothing:TRUE];
			[image setScale:1.1f];
			[image setAnchorWithX:0.5f andY:0.5f];
			image.x = self.stage.stageWidth*0.5f;
			image.y = self.stage.stageHeight*0.5f;
			[self addChild:image];
			
			
			
			
			NSString *score = [NSString stringWithFormat:@"%0.2f", count];
			
			[self removeChild:atxtfield];		
			atxtfield = [PXTextField new];
			atxtfield.font = @"Helvetica";
			atxtfield.fontSize = 30.0f;	
			atxtfield.text = score;
			uint textColor = 0xFFFFFF;
			atxtfield.textColor = textColor;
			atxtfield.align = PXTextFieldAlign_Center;
			atxtfield.x = self.stage.stageWidth * 0.4f;
			atxtfield.y = self.stage.stageHeight * 0.5f;
			atxtfield.rotation = -90.0f;
			[self addChild:atxtfield];
			
			// Upload Score!
			NSString *testUrl = [NSString stringWithFormat:
								 @"http://hello-o.appspot.com/?action=postData&table=PlayerScores&player=Ben&score=%@", score];
			testUrl = [testUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
			NSLog(@"testUrl: %@", testUrl);
			
			NSURL *url = [NSURL URLWithString:testUrl];
			ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
			[request startSynchronous];
			NSError *error = [request error];
			if (!error) {
				NSString *response = [request responseString];
				NSLog(@"%@", response);
			}
		}
	}// else {
	//	worldIsPaused = FALSE;
	//}
	
	// Destroy
	[self destroyBodies];
}

- (void)accelerometer:(UIAccelerometer *)anAccelerometer didAccelerate:(UIAcceleration *)anAcceleration
{
	b2Vec2 gravity;
	gravity.Set( GRAVITYRATIO * anAcceleration.y * -POINTS_PER_METER, GRAVITYRATIO * anAcceleration.x * -POINTS_PER_METER );
	physicsWorld->SetGravity(gravity);
}

@end
