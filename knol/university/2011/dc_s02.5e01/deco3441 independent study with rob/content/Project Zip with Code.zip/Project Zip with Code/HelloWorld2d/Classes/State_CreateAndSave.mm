//
//  State_CreateAndSave.mm
//  HelloWorld2d
//
//  Created by Hanley Weng on 9/05/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import "State_CreateAndSave.h"

#import "Box2DUtils.h"
#import "PKBox2DDebugLayer.h"

#import "DynamicCircle.h"
#import "StaticBlock.h"
#import "MovableSprite.h"
#import "GridEditor.h"

#import "ASIHTTPRequest.h"
#import "JSON/JSON.h"

@interface State_CreateAndSave(Private)
- (void) createScene;
@end

@implementation State_CreateAndSave


- (void) dealloc
{
	// Remove All Bodies
	b2Body *node = physicsWorld->GetBodyList();
	while (node) {
		b2Body *b = node;
		node = node->GetNext();
		
		if (b->GetUserData() != NULL) {
			
			Actor *sprite = (Actor *) b->GetUserData();
			[sprite nullifyBody];
			[self removeChild:sprite];
			b->SetUserData(NULL);
			// Above lines of code 'works'ish - just have to make sure sprite covers entire body.
		}	
	}
	
	// PhysicsWorld
	delete physicsWorld;
	physicsWorld = NULL;
	
	// Unload all the listeners
	if (destructionListener)
	{
		delete destructionListener;
		destructionListener = NULL;
	}
	
	if (contactListener)
	{
		delete contactListener;
		contactListener = NULL;
	}
	
	// Buttons
	//[plusBtn release];
	[saveBtn release];
	[btn_State_Menu release];
	
	//plusBtn = nil;
	saveBtn = nil;
	btn_State_Menu = nil;
	
	// Bools
	//worldIsPaused = nil;
	
	// Accel
	[[UIAccelerometer sharedAccelerometer] setDelegate:nil];	
	
	// Super
	[super dealloc];
}

- (void) initializeAsRoot
{
	
	[super initializeAsRoot];
	[self setType:@"State_CreateAndSave"];
	
	self.stage.frameRate = 60.0;
	self.stage.nativeView.multipleTouchEnabled = NO;
	
	timeStep = 1.0f / self.stage.frameRate;
	velocityIterations = 10;
	positionIterations = 10;
	
	b2Vec2 gravity(0.0f, GRAVITY);
	bool doSleep = false;
	physicsWorld = new b2World(gravity, doSleep);
	
	destructionListener = NULL;
	contactListener = NULL;
	
	// Debug Graphics Layer
	/*
	PKBox2DDebugLayer *layer = [PKBox2DDebugLayer new];
	layer.physicsWorld = physicsWorld;
	layer.scale = POINTS_PER_METER;
	layer.touchPicking = YES; //
	
	[self addChild:layer]; //
	[layer release];
	 */
	
	[self createScene];
	[self addEventListenerOfType:PX_EVENT_ENTER_FRAME listener:PXListener(onEnterFrame)];
	
}

// -----------------------------------------------------------------------------------------------------------------------------

- (void) createScene
{	
	float stageWidth = self.stage.stageWidth; //480
	float stageHeight = self.stage.stageHeight; //320
	
	// EVENTS
	//NOTE: self.stage does not seem to want to be removed properly.
	[self addEventListenerOfType:PX_TOUCH_EVENT_TOUCH_DOWN listener:PXListener(onTouchDown:)];
	[self addEventListenerOfType:PX_TOUCH_EVENT_TOUCH_MOVE listener:PXListener(onTouchMove:)];
	// BACKGROUND IMAGE
	PXTextureData *bgTextureData;
	PXTexture *bgTexture;
	
	bgTextureData = [PXTextureData textureDataWithContentsOfFile:@"BgNotepad.jpg"];
	bgTexture = [[PXTexture alloc] initWithTextureData:bgTextureData];
	[bgTexture setAnchorWithX:0.0f andY:0.0f];
	bgTexture.x=0.0f;
	bgTexture.y=0.0f;
	[self addChild:bgTexture];
	
	bgTextureData = [PXTextureData textureDataWithContentsOfFile:@"TransparentBg.png"];
	bgTexture = [[PXTexture alloc] initWithTextureData:bgTextureData];
	[bgTexture setAnchorWithX:0.0f andY:0.0f];
	bgTexture.x=0.0f;
	bgTexture.y=0.0f;
	[self addChild:bgTexture];
	
	//Bounds
	PXRectangle *bounds = [PXRectangle rectangleWithX:0.0f andY:0.0f andWidth:stageWidth andHeight:stageHeight];
	[Box2DUtils staticBorderInWorld:physicsWorld rect:bounds thickness:10.0f];
	
	// .h variables
	worldIsPaused = FALSE;
	count = 0;
	atxtfield = [PXTextField new];
	[self addChild:atxtfield];
	
	// Grid
	grid = [GridEditor new];
	[grid initialize:physicsWorld];
	[self addChild:grid];
	
	// StartPt, EndPt
	startPt = [MovableSprite new];
	[startPt initialize:physicsWorld withImage:@"StartIconWhite.png"];
	[startPt setTargetX:stageWidth*1/7 targetY:stageHeight*0.5f];
	[startPt setX:[startPt getTargetX] andY:[startPt getTargetY]];
	[self addChild:startPt];
	
	endPt = [MovableSprite new];
	[endPt initialize:physicsWorld withImage:@"StarIconWhite.png"];
	[endPt setTargetX:stageWidth*6/7 targetY:stageHeight*0.5f];
	[endPt setX:[endPt getTargetX] andY:[endPt getTargetY]];
	[self addChild:endPt];	
	
	// Create some Dummy objects
	hero = [DynamicCircle new];
	[hero initialize:physicsWorld];
	[hero setX:[startPt getTargetX] andY:[startPt getTargetY]];
	[self addChild:hero];
		
	// Additional Buttons: Plus Button, Save Button
	PXTextureData *textureData;
	PXTexture *texture;
	
	/*
	textureData = [PXTextureData textureDataWithContentsOfFile:@"AddIcon.png"];
	texture = [[PXTexture alloc] initWithTextureData:textureData];
	[texture setAnchorWithX:1.0f andY:1.0f];
	plusBtn = [[PXSimpleButton alloc] initWithUpState:texture downState:texture hitTestState:texture];
	plusBtn.x = self.stage.stageWidth;
	plusBtn.y = self.stage.stageHeight;
	[self addChild:plusBtn];
	[plusBtn addEventListenerOfType:PX_TOUCH_EVENT_TOUCH_DOWN listener:PXListener(plusBtnTouchDown:)];
	 */
	
	textureData = [PXTextureData textureDataWithContentsOfFile:@"SaveIcon.png"];
	texture = [[PXTexture alloc] initWithTextureData:textureData];
	[texture setAnchorWithX:0.0f andY:0.0f];
	saveBtn = [[PXSimpleButton alloc] initWithUpState:texture downState:texture hitTestState:texture];
	saveBtn.x = 0.0f;
	saveBtn.y = self.stage.stageHeight*1/9;
	[self addChild:saveBtn];
	[saveBtn addEventListenerOfType:PX_TOUCH_EVENT_TOUCH_UP listener:PXListener(saveBtnTouchUp:)];
	
	// State_Menu Button
	PXTextureData *textureData3 = [PXTextureData textureDataWithContentsOfFile:@"StopIcon.png"];
	PXTexture *texture3 = [[PXTexture alloc] initWithTextureData:textureData3];
	[texture3 setAnchorWithX:0.0f andY:0.0f];
	btn_State_Menu = [[PXSimpleButton alloc] initWithUpState:texture3 downState:texture3 hitTestState:texture3];
	btn_State_Menu.x = 0.0f;//self.stage.stageWidth;
	btn_State_Menu.y = 0.0f;//self.stage.stageHeight*2/5;
	[self addChild:btn_State_Menu];
	[btn_State_Menu addEventListenerOfType:PX_TOUCH_EVENT_TOUCH_UP listener:PXListener(stateMenuPressed:)];
	
	// start accelerometer
	[[UIAccelerometer sharedAccelerometer] setDelegate:self];
	
}

- (void) possiblyUpdateGrid:(PXTouchEvent *)event
{
	[grid updateMatrixFromEvent:event];
}

- (void) onTouchDown: (PXTouchEvent *)event
{
	targetX = event.stageX;
	targetY = event.stageY;
	[self possiblyUpdateGrid:event];
}

- (void) onTouchMove: (PXTouchEvent *)event
{
	targetX = event.stageX;
	targetY = event.stageY;
	[self possiblyUpdateGrid:event];
}

- (void) stateMenuPressed: (PXTouchEvent *) event
{
	[self setDesiredState:@"State_Menu"];
}

/*
- (void) plusBtnTouchDown: (PXTouchEvent *)event
{
	
	StaticBlock * dba2 = [StaticBlock new];
	[dba2 initialize:physicsWorld];
	[self addChild:dba2];
}
*/
- (void) saveBtnTouchUp: (PXTouchEvent *) event
{
	//
	DynamicCircle * do2 = [DynamicCircle new];
	[do2 initialize:physicsWorld];
	[self addChild:do2];
	//
	
	NSMutableArray *staticBlocks = [[NSMutableArray alloc] init];	
	b2Body *node = physicsWorld->GetBodyList();
	while (node) {
		b2Body *b = node;
		node = node->GetNext();	
		if (b->GetUserData() != NULL) {	
			Actor *myActor = (Actor *)b->GetUserData();
			if (![myActor isDead]) {
				if ([myActor isType:@"StaticBlock"]) {
					CGFloat bx = (CGFloat) (b->GetPosition().x * POINTS_PER_METER);
					CGFloat by = (CGFloat) (b->GetPosition().y * POINTS_PER_METER);
					NSDictionary *blockInfo = [NSDictionary dictionaryWithObjectsAndKeys:
											   [NSString stringWithFormat:@"%0.0f",bx], @"x",
											   [NSString stringWithFormat:@"%0.0f",by], @"y",
											   nil];
					[staticBlocks addObject:blockInfo];
				}
			}
		}	
	}
	
	NSDictionary *startPtInfo = [NSDictionary dictionaryWithObjectsAndKeys:
								 [NSString stringWithFormat:@"%0.0f", [startPt getTargetX]], @"x",
								 [NSString stringWithFormat:@"%0.0f", [startPt getTargetY]], @"y",
								 nil];
	
	NSDictionary *endPtInfo = [NSDictionary dictionaryWithObjectsAndKeys:
								 [NSString stringWithFormat:@"%0.0f", [endPt getTargetX]], @"x",
								 [NSString stringWithFormat:@"%0.0f", [endPt getTargetY]], @"y",
								 nil];
	
	NSDictionary *postData = [NSDictionary dictionaryWithObjectsAndKeys:
							  staticBlocks, @"actor",
							  startPtInfo, @"startPt",
							  endPtInfo, @"endPt",
							  nil];
	
	NSString *postDataString = [postData JSONRepresentation];
	
	
	//NOTE: The LIMIT a url can handle before saying: "Error 414 (Request-URI Too Large)!!1 is between 64-128 objects.
	NSString *postUrl = [NSString stringWithFormat:@"http://hello-o.appspot.com/?action=postData&table=Entry&message=%@", postDataString];
	postUrl = [postUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	NSURL *url = [NSURL URLWithString:postUrl];
	ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
	[request startSynchronous];
	NSError *error = [request error];
	if (!error) {
		NSString *response = [request responseString];
		NSLog(@"%@", response);
		NSLog(@" ");
		NSLog(@" ");
		NSLog(@" ");
		NSLog(@" ");
		NSLog(@" ");
		NSLog(@" ");
	}
}

- (void) destroyBodies
{
	b2Body *node = physicsWorld->GetBodyList();
	while (node) {
		b2Body *b = node;
		node = node->GetNext();
		
		if (b->GetUserData() != NULL) {
			
			Actor *sprite = (Actor *) b->GetUserData();
			if ([sprite isDead]) {
				
				// NOTE: Can't figure out deletion (of b2body). Faking it. //Crashes if body is destroyed when touched. (Possibly Joins). (Possibly References). //If no 'nice' solution in the end. Simply delete latently, when we know user has reset their touch points.
				b->SetTransform(b2Vec2_px2m(-50.0f, -50.0f), 0.0f);
				[sprite setDead:FALSE];
				// TEMPORARY CODE: If StaticBlock, change the target to stop it moving!
				if ([sprite isType:@"StaticBlock"]) {
					StaticBlock *spriteb = (StaticBlock *) sprite;
					[spriteb setTargetX:0.0f targetY:0.0f];
					[sprite setDead:TRUE];
				}
				//[sprite nullifyBody];
				//[self removeChild:sprite];
				//b->SetUserData(NULL);
				// Above lines of code 'works'ish - just have to make sure sprite covers entire body.
			}
		}	
	}
}

- (void) onEnterFrame
{	
	// Step
	if (!worldIsPaused) {
		physicsWorld->Step(timeStep, velocityIterations, positionIterations);
		count += 1/self.stage.frameRate;
	}
	
	
	// Scene Elements
	for (b2Body *b = physicsWorld->GetBodyList(); b; b=b->GetNext())
	{
		CGFloat bx = (CGFloat) (b->GetPosition().x * POINTS_PER_METER);
		CGFloat by = (CGFloat) (b->GetPosition().y * POINTS_PER_METER);
		
		if (b->GetUserData() != NULL) {
			
			Actor *spritet = (Actor *)b->GetUserData();
			spritet.x = bx;
			spritet.y = by;
			spritet.rotation = (CGFloat) (b->GetAngle() * 180 / M_PI);
			
			//NSLog(@"Type: %@", [spritet getType]);
			
			//Set Target if it's a static block
			if ([spritet isType:@"StaticBlock"]) {
				StaticBlock *spriteb = (StaticBlock *) spritet;
				if ([spriteb isTouchedDown]) {
					[spriteb setTargetX:targetX targetY:targetY];
				}
			}
			//Same thing if it's a movable sprite
			if ([spritet isType:@"MovableSprite"]) {
				MovableSprite *spriteb = (MovableSprite *) spritet;
				if ([spriteb isTouchedDown]) {
					[spriteb setTargetX:targetX targetY:targetY];
				}
			}
			
		}
	}
	
	// Update gridSBlocks
	for (int x=0; x<NUMCOLS; x++) {
		for (int y=0; y<NUMROWS; y++) {
			// If there shouldn't be a block, but there's one, delete.
			if ([grid matrixValueAtX:x AtY:y] == 0) {
				if (gridSBlocks[x][y] != nil) {
					StaticBlock *sblock = (StaticBlock *) gridSBlocks[x][y];
					[sblock setDead:TRUE];
					gridSBlocks[x][y] = nil;
				}
			}
			
			// If there should be a block, but there's none, add.
			if ([grid matrixValueAtX:x AtY:y] == 1) {
				if (gridSBlocks[x][y] == nil) {
					StaticBlock * sblock = [StaticBlock new];
					[sblock initialize:physicsWorld];
					[sblock setTouchDisabled:TRUE];
					[sblock setTouchCausesDeath:TRUE];
					int realX = x*GRIDGAP + GRIDGAP/2 + 1;
					int realY = y*GRIDGAP + GRIDGAP/2 + 1;
					[sblock	setTargetX:realX targetY:realY];
					[sblock	setX:[sblock getTargetX] andY:[sblock getTargetY]];
					gridSBlocks[x][y] = sblock;
					[self addChild:sblock];
					
				}
			}
		}
	}
	
	/*
	for (int x=0; x<NUMCOLS; x++) {
		for (int y=0; y<NUMROWS; y++) {
			// If there shouldn't be a block, but there's one, delete.
			if (matrix[x][y] == 0) {
				if (displayMatrix[x][y] != NULL) {
					PXTexture *block = (PXTexture *) displayMatrix[x][y];
					[self removeChild:block];
					displayMatrix[x][y] = NULL;
				}
			}
			
			// If there should be a block, but there's none, add.
			if (matrix[x][y] == 1) {
				if (displayMatrix[x][y] == NULL) {
					PXTextureData *blockTextureData = [PXTextureData textureDataWithContentsOfFile:@"BlankIcon.png"];
					PXTexture *block = [[PXTexture alloc] initWithTextureData:blockTextureData];
					[block setSmoothing:TRUE];
					[block setScale:0.50f];
					[block setAnchorWithX:0.5f andY:0.5f];
					block.x = x*GRIDGAP+GRIDGAP/2+1;
					block.y = y*GRIDGAP+GRIDGAP/2+1;
					
					displayMatrix[x][y] = block;
					[self addChild:block];
				}
			}
		}
	}
	 */
	
	// Destroy
	[self destroyBodies];
}

- (void)accelerometer:(UIAccelerometer *)anAccelerometer didAccelerate:(UIAcceleration *)anAcceleration
{
	b2Vec2 gravity;
	gravity.Set( GRAVITYRATIO * anAcceleration.y * -POINTS_PER_METER, GRAVITYRATIO * anAcceleration.x * -POINTS_PER_METER );
	physicsWorld->SetGravity(gravity);
}



@end
