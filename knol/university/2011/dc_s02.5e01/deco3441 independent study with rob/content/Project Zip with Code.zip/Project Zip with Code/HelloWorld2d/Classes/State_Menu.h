//
//  State_Menu.h
//  HelloWorld2d
//
//  Created by Hanley Weng on 8/05/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import "Pixelwave.h"

#import "State_Actor.h"

@interface State_Menu : State_Actor
{
	PXSimpleButton *btn_State_Play, *btn_State_CreateAndSave;
}

- (void) initializeAsRoot;

@end
