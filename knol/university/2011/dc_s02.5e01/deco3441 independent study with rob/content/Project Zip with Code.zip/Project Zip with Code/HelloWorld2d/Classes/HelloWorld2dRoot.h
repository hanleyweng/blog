//
//  HelloWorld2dRoot.h
//  HelloWorld2d
//
//  Created by Hanley Weng on 19/04/11.
//  Copyright Hanley Weng. 2011. All rights reserved.
//

#import "Pixelwave.h"

@class State_Actor;

@interface HelloWorld2dRoot : PXSprite
{
	State_Actor *curState;
}

- (void) initializeAsRoot;

@end