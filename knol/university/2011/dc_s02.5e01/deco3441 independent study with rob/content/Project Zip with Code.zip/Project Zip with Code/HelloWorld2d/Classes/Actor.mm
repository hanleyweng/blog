//
//  Actor.m
//  HelloWorld2d
//
//  Created by Hanley Weng on 24/04/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import "Actor.h"

@interface Actor ()

@end


@implementation Actor

- (id) init
{
	if (self = [super init])
	{
		[self setDead:FALSE];
		touchedDown = FALSE;
		
		[self addEventListenerOfType:PX_TOUCH_EVENT_TOUCH_DOWN listener:PXListener(onTouchDown:)];
		
		[self addEventListenerOfType:PX_TOUCH_EVENT_TOUCH_UP listener:PXListener(onTouchUp:)];
		[self addEventListenerOfType:PX_TOUCH_EVENT_TOUCH_OUT listener:PXListener(onTouchUp:)];
		[self addEventListenerOfType:PX_TOUCH_EVENT_TOUCH_CANCEL listener:PXListener(onTouchUp:)];
		
	}

	return self;
}

- (void) dealloc
{
	[self removeAllEventListeners]; //
	type = nil;
	
	delete myWorld;
	myWorld = NULL;
	myBody = NULL;
	
	[super dealloc];
}

- (NSString *) getType
{
	return type;
}

- (void) setType:(NSString *)_type
{
	type = _type;
}

- (BOOL) isType:(NSString *)_type
{
	if ([type isEqualToString:_type]) {
		return TRUE;
	}
	return FALSE;	
}

- (BOOL) isTouchedDown 
{
	//NSLog(@"isTouchedDown: %d", touchedDown);
	return touchedDown;
}

- (BOOL) isDead
{
	return isDead;
}

- (void) setDead:(BOOL)_isDead
{
	isDead = _isDead;
}

- (void) onTouchDown:(PXTouchEvent *)event
{
	touchedDown = TRUE;
}

- (void) onTouchUp:(PXTouchEvent *)event
{
	touchedDown = FALSE;
}

- (void) nullifyBody
{
	myBody = NULL;
}

- (void) initialize:(b2World *)_myWorld
{
	// World
	myWorld = _myWorld;
}	

@end
