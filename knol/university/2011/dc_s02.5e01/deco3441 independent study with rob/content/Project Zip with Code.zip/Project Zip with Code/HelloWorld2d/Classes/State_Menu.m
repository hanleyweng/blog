//
//  State_Menu.m
//  HelloWorld2d
//
//  Created by Hanley Weng on 8/05/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import "State_Menu.h"

@implementation State_Menu


- (void) dealloc
{
	[btn_State_Play release];
	btn_State_Play = nil;
	[super dealloc];
}

- (void) initializeAsRoot
{	
	[super initializeAsRoot];	
	[self setType:@"State_Menu"];
	
	PXTextureData *textureData;
	PXTexture *texture;
	
	textureData = [PXTextureData textureDataWithContentsOfFile:@"TitleM1.png"];
	texture = [[PXTexture alloc] initWithTextureData:textureData];
	[texture setAnchorWithX:0.0f andY:0.0f];
	texture.x=0.0f;
	texture.y=0.0f;
	[self addChild:texture];
	
	textureData = [PXTextureData textureDataWithContentsOfFile:@"t40x130.png"];
	texture = [[PXTexture alloc] initWithTextureData:textureData];
	[texture setAnchorWithX:0.0f andY:0.5f];	
	btn_State_Play = [[PXSimpleButton alloc] initWithUpState:texture downState:texture hitTestState:texture];
	btn_State_Play.x = 246.65f;
	btn_State_Play.y = self.stage.stageHeight/2;
	[self addChild:btn_State_Play];
	[btn_State_Play addEventListenerOfType:PX_TOUCH_EVENT_TOUCH_UP listener:PXListener(statePlayPressed:)];

	textureData = [PXTextureData textureDataWithContentsOfFile:@"t40x130.png"];
	texture = [[PXTexture alloc] initWithTextureData:textureData];
	[texture setAnchorWithX:0.0f andY:0.5f];
	btn_State_CreateAndSave = [[PXSimpleButton alloc] initWithUpState:texture downState:texture hitTestState:texture];
	btn_State_CreateAndSave.x = 403.6f;
	btn_State_CreateAndSave.y = self.stage.stageHeight/2;
	[self addChild:btn_State_CreateAndSave];
	[btn_State_CreateAndSave addEventListenerOfType:PX_TOUCH_EVENT_TOUCH_UP listener:PXListener(stateCreateAndSavePressed:)];
	
}

- (void) statePlayPressed: (PXTouchEvent *)event
{
	[self setDesiredState:@"State_Play"];
}

- (void) stateCreateAndSavePressed: (PXTouchEvent *)event
{
	[self setDesiredState:@"State_CreateAndSave"];
}

@end
