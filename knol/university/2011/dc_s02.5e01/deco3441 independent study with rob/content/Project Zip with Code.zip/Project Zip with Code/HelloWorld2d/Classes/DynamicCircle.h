//
//  DynamicCircle.h
//  HelloWorld2d
//
//  Created by Hanley Weng on 23/04/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import "Box2d.h"
#import "Pixelwave.h"

#import "Actor.h"

@interface DynamicCircle : Actor 
{
}
- (void) initialize:(b2World *)_myWorld;
- (void) setX:(float)_x andY:(float)_y;

@end
