//
//  AppDelegate_iPhone.h
//  HelloWorld2d
//
//  Created by Hanley Weng on 19/04/11.
//  Copyright 2011 Hanley Weng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Pixelwave.h"

@interface AppDelegate_iPhone : NSObject <UIApplicationDelegate>
{
@private
    UIWindow *window;
	PXView *pixelView;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
