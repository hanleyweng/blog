import java.util.ArrayList;

import processing.core.*;

public class PSketch extends PApplet {
	public static void main(String args[]) {
		PApplet.main(new String[] { "--present", "PSketch" });
	}
	
	//NOTE: SHOULD ONLY STICK TO FLOATS WITH PROCESSING SKETCHES
	//Should also look into creating future tasks natively with processing.js
	int swidth, sheight;
	PFont font;
	int fontSize;
	ArrayList<Node> nodes;
	ArrayList<Edge> edges;
	int hue = (int) (Math.random()*100);
	float dNodeSize = 15;
	float dEdgeTipWidth = 5;
	float dEdgeSelfLoopSize = (float) (dNodeSize*1.5);
	float dMinNodeMouseDist = (float) (dNodeSize*1.0);
	boolean mousePressing = false;
	Node mousePressingNode;
	public void setup() {
		//Variables
		swidth = 500;
		sheight = 500;
		int numNodes = 20;
		double edgeProbability = 0.07;
		
		font = loadFont("Serif-48.vlw");
		fontSize = 48;
		textFont(font);
		
		colorMode(HSB,100);
		
		size(swidth, sheight);
		smooth();
		
		//Generating Nodes
		nodes = new ArrayList<Node>();
		for (int n=0; n<numNodes; n++) {
			//97 is 'a' in ascii
			Node nn = new Node(Character.toString((char)(n+97)), random(0,swidth), random(0, sheight), true, true);
			nodes.add(nn);
		}
		
		//Generating Edges
		edges = new ArrayList<Edge>();
		for (int e=0; e<numNodes; e++) {
			for (int f=0; f<numNodes; f++) {
				if (Math.random() < edgeProbability) {
					Edge ne = new Edge(nodes.get(e),nodes.get(f));
					edges.add(ne);
				}
			}
		}
		
		//Finding start node and displaying it.
		Node startNode = edges.get(0).n1;
		//Limit to going through 'numNodes' times
		for (int e=0; e<numNodes; e++) {
			for (int i=0; i<numNodes; i++) {
				Edge edge = edges.get(e);
				Node n1 = edge.n1;
				Node n2 = edge.n2;
				if (n2==startNode) {
					startNode = n1; //set to parent node
				}
			}
		}
		startNode.hidden=false;
		
	}
	
	float oMouseX;
	float oMouseY;
	int mouseClickedDistThresh = 10;
	public void mousePressed() {
		oMouseX = mouseX;
		oMouseY = mouseY;
	}
	
	public void mouseReleased() {
		mousePressing = false;
		//check if mouse'clicked'
		//if mouse dragged, then expand / collapse
		if ( dist(oMouseX, oMouseY, mouseX, mouseY) < mouseClickedDistThresh) {
			Node n = mousePressingNode;
			if (n!= null) {
				n.collapsed = !n.collapsed;
				//Tell all node's neighbors to show/hide (show for now).
				//Need to iterate through connected nodes and hide their children too
				if (!n.collapsed){
					expandNodesChildren(n);
				} else {
					hideNodesChildren(n);
				}
				
			}
		}
		mousePressingNode = null;
	}
	
	void expandNodesChildren(Node n) {
		for (int e=0; e<edges.size(); e++) {
			Edge edge = edges.get(e);
			Node a = edge.n1;
			Node b = edge.n2;
			if (a==n) {
				b.hidden = false;
			}
		}
	}
	
	void hideNodesChildren(Node n) {
		int i = 100;
		ArrayList<Node> neighbors = new ArrayList<Node>();
		for (int e=0; e<edges.size(); e++) {
			Edge edge = edges.get(e);
			Node a = edge.n1;
			Node b = edge.n2;
			if (a==n) {
				if (b!=n) {
					if (!b.hidden) { //Cycles was the problem!
						neighbors.add(b);
					}
				}
				b.hidden = true;
				b.collapsed = true;
			}
		}
		println(n.label+": "+neighbors);
		for (int nei=0; nei<neighbors.size(); nei++) {
			Node b = neighbors.get(nei);
			this.hideNodesChildren(b);
		}
	}
	
	public void draw() {
		background(100);
		
		//Press space to change to random hue!
		if (keyPressed) {
			if (key == ' ') {
				hue = (int) (Math.random()*100);
			}
		}
		
		//Movement of Nodes.
		//Hovering State
		if (!mousePressing) {
			try {
				//for each node, check mouse's distance to that node, //remember smallest distance
				//if smallest distance is within threshold, (radius), then change cursor
				float closestDist = Float.MAX_VALUE;
				int closestNode = -1;
				for (int n=0; n<nodes.size(); n++) {
					Node cn = nodes.get(n);
					if (!cn.hidden){ 
						float d = dist(mouseX, mouseY, cn.x, cn.y);
						if (d<closestDist) {
							closestDist = d;
							closestNode = n;
						}
					}
				}
				if (closestNode!=-1) {
					if (closestDist<=dMinNodeMouseDist) {
						Node cn = nodes.get(closestNode);
						stroke(hue,70,90);
						fill(hue,50,90, 10);
						ellipse(cn.x,cn.y,dNodeSize*2,dNodeSize*2);
						
						if (mousePressed) {
							cursor(CROSS);
							mousePressing = true;
							mousePressingNode = cn;
						} else {
							cursor(HAND);
						}
					} else {
						cursor(ARROW);
					}
				}
			} catch (Exception e) {println(e);};
		}
		
		//Continual movement of a Node
		if (mousePressing) {
			Node n = mousePressingNode;
			cursor(CROSS);
			n.x = mouseX;
			n.y = mouseY;
			stroke(hue,70,90);
			fill(hue,50,90, 25);
			ellipse(n.x,n.y,dNodeSize*2,dNodeSize*2);
		}
		
		//Drawing Edges
		for (int e=0; e<edges.size(); e++) {
			Edge ce = edges.get(e);
			if (ce.isHidden()) {
				continue;
			}
			
			stroke(hue,50,10, 50);
			fill(hue,50,70, 50);
			
			Node n1 = ce.n1;
			Node n2 = ce.n2;
			if (n1 != n2) {
				//line(n1.x, n1.y, n2.x, n2.y);
				double oAngle = atan2(n2.y-n1.y, n2.x-n1.x);
				double angle = Math.PI/2 - oAngle;
				float d = dEdgeTipWidth;
				beginShape();
				vertex(n1.x, n1.y);
				vertex(n2.x+cos((float)angle)*d, n2.y-sin((float)angle)*d);
				vertex(n2.x, n2.y);
				vertex(n2.x-cos((float)angle)*d, n2.y+sin((float)angle)*d);
				vertex(n1.x, n1.y);
				endShape(CLOSE);
				
				pushMatrix();
				fill(hue,20,50);
				translate((n1.x+n2.x)/2, (n1.y+n2.y)/2);
				//double rAngle = oAngle; //Always -Math.PI/2 to Math.PI/2, or NOT Math.PI/2 to Math.PI*3/2 ..flipt right way
				//if (rAngle>Math.PI/2 && rAngle<Math.PI*3/2) {					rAngle = Math.PI*2-rAngle;				}
				rotate((float) oAngle);
				scale((float)0.5);
				String display = n1.label+">"+n2.label;
				text(display,0-display.length()/2*fontSize,-fontSize/4);
				//rect(0,0,10,10);
				popMatrix();
				
			} else {
				fill(hue,50,90, 50);
				ellipse(n1.x,n1.y,dEdgeSelfLoopSize,dEdgeSelfLoopSize);
			}
			
		}
		
		//Drawing Nodes
		for (int n=0; n<nodes.size(); n++) {
			Node cn = nodes.get(n);
			if (cn.hidden) {
				continue;
			}
			
			strokeWeight(2);
			stroke(hue,100,100);
			
			fill(hue,100,100);
			text(cn.label,cn.x,cn.y-dNodeSize);
			fill(hue,0,100);
			ellipse(cn.x,cn.y,dNodeSize,dNodeSize);
		}
	}
	
	class Edge {
		Node n1;
		Node n2;
		//float w;
		//String label;
		public Edge(Node _a, Node _b) {
			n1 = _a;
			n2 = _b;
		}
		boolean isHidden() {
			if (n1.hidden) {
				return true;
			}
			if (n2.hidden){
				return true;
			}
			return false;
		}
	}
	
	class Node {
		String label;
		float x;
		float y;
		//float w;
		boolean hidden;
		boolean collapsed;
		
		public Node() {
			label = "";
			x = -1;
			y = -1;
			hidden = false;
			collapsed = true;
		}
		
		public Node(String _label, float _x, float _y, boolean _hidden, boolean _collapsed) {
			this(); //call the default constructor
			label = _label;
			x = _x;
			y = _y;
			hidden = _hidden;
			collapsed = _collapsed;
		}
		
	}
}
