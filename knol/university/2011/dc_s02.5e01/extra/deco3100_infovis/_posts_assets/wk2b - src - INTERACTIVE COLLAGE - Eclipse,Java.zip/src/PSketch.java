import java.io.File;

import processing.core.*;

public class PSketch extends PApplet {
	public static void main(String args[]) {
		PApplet.main(new String[] { "--present", "PSketch" });
	}
	/**
	 * Collage of Images.
	 * Average color of tile-images are mapped to average color of the area they cover of the base (overall) image.
	 * MouseOver any one image to slightly expand.
	 * MousePress on an image to zoom into it.
	 */
	PImage img;
	PImage[] timg;
	int[][] tcol;
	int[][][] imgCol;
	int maxTimgs;
	PFont font;
	int swidth, sheight;
	int twidth, theight;
	int rows, cols;
	PImage mon;
	int[][] monTile;
	public void setup() {
		
		maxTimgs = 500;
		twidth = 8;
		theight = twidth;
		swidth = 470;
		sheight = 703;
		rows = swidth/twidth;
		cols = (int) Math.ceil(sheight*1.0/theight);
		size(swidth, sheight);	
		
		noStroke();
		
		//getting all files
		String tileFolder = "pictures";
		String path = sketchPath+"/"+tileFolder;
		String[] filenames = listFileNames(path);
		println(filenames);
		int timgNum = filenames.length;
		if (filenames.length>maxTimgs) {
			timgNum = maxTimgs;
		}
		timg = new PImage[timgNum];
		tcol = new int[timgNum][3];
		
		//Load Tile Images
		println("Loading Tile Images: ");
		for (int i=0; i<timg.length; i++) {
			timg[i] = loadImage(tileFolder+"/"+filenames[i]);
			//Calculate mean tile color
			tcol[i] = returnMeanColor(timg[i]);
			println("\tTiles: "+(int)((i+1)*100.0/timg.length)+" %");
		}
		//load base image
		img = loadImage("barackhopeposter1.jpg");
		//analyze base img //and draw as tiles
		imgCol = new int[rows+1][cols+1][3];
		monTile= new int[rows+1][cols+1];
		for (int xn = 0; xn<=rows; xn++) {
			for (int yn=0; yn<=cols; yn++) {
				//imgCol[xn][yn] = returnMeanColorFromSegment(img, xn*twidth, xn*twidth+twidth, yn*theight, yn*theight+theight);
				imgCol[xn][yn] = returnMeanColorFromSegment(img, xn*twidth,yn*theight,xn*twidth+1,yn*theight+1);
				fill(imgCol[xn][yn][0],imgCol[xn][yn][1],imgCol[xn][yn][2],255);
				rect(xn*twidth,yn*theight,twidth,theight);
			}
		}
		
		//Generating Montage Image
		println("Generating Montage...");
		mon = thisGenerateMontage();
		println("Montage Generated.");
	}
	float mtsizeDefault = 40;
	float mtsizeGrowthR = 15;
	float mtsizeDeclineR = 35;
	float mtsizeMax = 200;
	float mtsizeMin = mtsizeDefault;
	float mtsize = mtsizeDefault;
	public void draw() {
		pushMatrix();
		
		image(mon,0,0,swidth,sheight);
		
		//on mouseDown, expand image above current point, according to how long mouse is held
		try {
			int mouseTileI = monTile[mouseX/twidth][mouseY/theight];
			
			image(timg[mouseTileI],(mouseX-mouseX%twidth)-mtsize/2,(mouseY-mouseY%theight)-mtsize/2,mtsize,mtsize);
			
			if (mousePressed) {
				noCursor();
				if (mtsize<mtsizeMax) {
					mtsize += mtsizeGrowthR;
				}
			} else {
				cursor(CROSS);
				if (mtsize>mtsizeMin) {
					mtsize -= mtsizeDeclineR;
				} else {
					mtsize = mtsizeMin;
				}
			}
			
		} catch(Exception e) {println(e);};
		
		popMatrix();
	}
	public PImage thisGenerateMontage() {
		PImage montage = null;
		image(img,0,0,swidth,sheight);
		//loadPixels();
		//updatePixels();
		//draw 'tiles' throughout image
		//int count = (int) (Math.random()*timg.length); //random start img
		//int totalPixels = cols*rows;
		for (int x=0; x<swidth; x+=twidth) {
			println("\tMontage: "+(int)(Math.round(x*100.0/swidth+1))+" %");
			for (int y=0; y<sheight; y+=theight) {
				//get pixel color
				
				//println("\tMontage: "+(int)((y+1+(x+1)*sheight)*100.0/(swidth*sheight)+1)+" %");
				
				int loc = x + y * img.width; //location pixel on 1D array
				float r = red(img.pixels[loc]);
				float g = green(img.pixels[loc]);
				float b = blue(img.pixels[loc]);

				//int baseColAvg[] = imgCol[x/twidth][y/theight];
				//int[] bcol = imgCol[x/twidth][y/theight];
				//float r = (float)bcol[0];
				//float g = (float)bcol[1];
				//float b = (float)bcol[2];
				
				
				//find image with closest rgb
				float minTcolDist = 99999999;
				float colDist;
				int minT = -1;
				for (int i=0; i<tcol.length; i++) {
					//iterate through each color set
					colDist = dist(tcol[i][0],tcol[i][1],tcol[i][2],r,g,b);
					if (colDist<minTcolDist) {
						minTcolDist = colDist;
						minT = i;
					}
				}
				monTile[x/twidth][y/theight] = minT;
				tint(255);
				image(timg[minT],x,y,twidth,theight);
				tint(r,g,b,75); //cheap, fade closer to image
				image(timg[minT],x,y,twidth,theight);
				
				//draw image
				//tint(r,g,b);
				//image(timg[count%timg.length],0,0,twidth,theight);
				
				//fill(r,g,b);
				//rect(x,y,twidth,theight);
				
				//count++;
			}
		}
		save("montage.jpg");
		montage = this.get(0,0,swidth,sheight);
		tint(255);
		return montage;
	}
	public int[] returnMeanColorFromSegment(PImage img, int x1, int y1, int x2, int y2) {
		//for now, doing averageColor
		int[] col = new int[3];
		//int colRange = 5;
		int totalR = 0;
		int totalG = 0;
		int totalB = 0;
		int total = (y2-y1)*(x2-x1);
		for (int x=x1; x<x2; x++) {
			for (int y=y1; y<y2; y++) {
				try {
					int loc = x + y * img.width;
					float r = red(img.pixels[loc]);
					float g = green(img.pixels[loc]);
					float b = blue(img.pixels[loc]);
					totalR += r;
					totalG +=g;
					totalB += b;
				} catch(Exception e) {};//occurs with null values, simply ignore
			}
		}
		col[0] = totalR/total;
		col[1] = totalG/total;
		col[2] = totalB/total;
		
		return col;
	}
	public int[] returnMeanColor(PImage img) {
		//for now, doing averageColor
		int[] col = new int[3];
		//int colRange = 5;
		int totalR = 0;
		int totalG = 0;
		int totalB = 0;
		for (int x=0; x<img.width; x++) {
			for (int y=0; y<img.height; y++) {
				int loc = x + y * img.width;
				float r = red(img.pixels[loc]);
				float g = green(img.pixels[loc]);
				float b = blue(img.pixels[loc]);
				totalR += r;
				totalG +=g;
				totalB += b;
			}
		}
		int total = img.width*img.height;
		col[0] = totalR/total;
		col[1] = totalG/total;
		col[2] = totalB/total;
		
		return col;
	}
	// This function returns all the files in a directory as an array of Strings
	public String[] listFileNames(String dir) {
		File file = new File(dir);
		if (file.isDirectory()) {
			String names[] = file.list();
			return names;
		} else {
			//Not a Directory
			return null;
		}
	}
	// This function returns all the files in a directory as an array of File objects 
	// This is useful if you want more info about the file
	public File[] listFiles(String dir) { 
		File file = new File(dir); 
		if (file.isDirectory()) {
			File[] files = file.listFiles();
			return files;
		} else {
			//if not in a directory
			return null;
		}
	}
	// Additional functions to get a list of all files in a directory and subdirectory
	// Recursive function to travserse subdirectories
}
