$contents = file_get_contents('http://www.google.com'); 
<?php 
 Echo "Hello, World!";
 ?> 