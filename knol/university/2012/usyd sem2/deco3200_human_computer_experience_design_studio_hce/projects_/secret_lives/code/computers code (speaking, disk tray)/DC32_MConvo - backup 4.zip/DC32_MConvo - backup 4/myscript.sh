#!/bin/bash

java -cp bin:libraries/Processing/core.jar:libraries/oscP5.jar Client
